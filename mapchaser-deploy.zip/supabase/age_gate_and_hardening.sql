-- Map Chaser — age gate + RLS hardening + upload limits
-- ALREADY APPLIED to Supabase project wadfkczjvollgdcgwyrl (tested first in a
-- rolled-back transaction). Kept for reference, and for setting up a NEW project.

begin;

-- ============ 1. AGE GATE ============
alter table public.profiles add column if not exists date_of_birth date;

insert into public.platform_settings (key, value)
  values ('min_signup_age', '18')
  on conflict (key) do nothing;

-- Email/password signups send date_of_birth in signup metadata: underage is
-- rejected at the moment of signup. Google OAuth users have no DOB yet; they
-- are let through here and gated until they provide one (see RLS below).
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  dob date;
  min_age int;
  dob_text text;
begin
  min_age := coalesce((select (value::text)::int from public.platform_settings where key = 'min_signup_age'), 18);
  dob_text := new.raw_user_meta_data->>'date_of_birth';

  if dob_text is not null and dob_text <> '' then
    dob := dob_text::date;
    if extract(year from age(current_date, dob)) < min_age then
      raise exception 'You must be at least % years old to join Map Chaser.', min_age;
    end if;
  end if;

  insert into public.profiles (id, full_name, date_of_birth)
    values (new.id, new.raw_user_meta_data->>'full_name', dob);
  insert into public.wallets (user_id) values (new.id);
  return new;
end;
$$;
revoke execute on function public.handle_new_user() from public, anon, authenticated;

-- ============ 2. PROFILE UPDATE GUARD ============
-- Fixes a real hole: the old "update own profile" policy let any signed-in user
-- change ANY column on their own row (role, suspended, strikes, verified...).
-- Non-admin, signed-in callers may now only change full_name, and set
-- date_of_birth once. Admins, the service role and SQL editor (no JWT) are trusted.
create or replace function public.handle_profile_update_guard()
returns trigger language plpgsql security definer set search_path = public as $$
declare min_age int;
begin
  if auth.uid() is not null and not public.is_admin() then
    if new.id is distinct from old.id
       or new.role is distinct from old.role
       or new.strikes is distinct from old.strikes
       or new.suspended is distinct from old.suspended
       or new.restricted is distinct from old.restricted
       or new.verified is distinct from old.verified then
      raise exception 'You are not allowed to change that field.';
    end if;
    if old.date_of_birth is not null and new.date_of_birth is distinct from old.date_of_birth then
      raise exception 'Date of birth cannot be changed once set. Contact support.';
    end if;
  end if;

  -- DOB being set for the first time (Google OAuth path): underage => suspended.
  if old.date_of_birth is null and new.date_of_birth is not null then
    min_age := coalesce((select (value::text)::int from public.platform_settings where key = 'min_signup_age'), 18);
    if extract(year from age(current_date, new.date_of_birth)) < min_age then
      new.suspended := true;
    end if;
  end if;

  return new;
end;
$$;
revoke execute on function public.handle_profile_update_guard() from public, anon, authenticated;

drop trigger if exists a_profile_update_guard on public.profiles;
create trigger a_profile_update_guard before update on public.profiles
  for each row execute function public.handle_profile_update_guard();

-- ============ 3. UPLOADS: no self-approval, age + suspension enforced in the DB ============
-- Fixes a real hole: users could insert an upload with status='approved',
-- publishing unmoderated content straight into the public gallery.
drop policy if exists "uploads: insert own" on public.uploads;
create policy "uploads: insert own" on public.uploads
  for insert with check (
    user_id = (select auth.uid())
    and status = 'pending'
    and points_awarded = 0
    and rejection_reason is null
    and exists (
      select 1 from public.profiles
      where id = (select auth.uid()) and suspended = false and date_of_birth is not null
    )
  );

-- ============ 4. WITHDRAWALS: age + suspension + restriction enforced in the DB ============
drop policy if exists "withdrawals: self request only" on public.withdrawals;
create policy "withdrawals: self request only" on public.withdrawals
  for insert with check (
    user_id = (select auth.uid())
    and exists (
      select 1 from public.profiles
      where id = (select auth.uid())
        and suspended = false and restricted = false and date_of_birth is not null
    )
  );

-- ============ 5. Reports / copyright claims can't be filed pre-resolved ============
drop policy if exists "reports: authenticated can file" on public.reports;
create policy "reports: authenticated can file" on public.reports
  for insert with check (
    reporter_id = (select auth.uid())
    and status = 'open' and resolved_at is null and resolved_by is null
    and not exists (select 1 from public.profiles where id = (select auth.uid()) and suspended = true)
  );

drop policy if exists "copyright: anyone can file" on public.copyright_claims;
create policy "copyright: anyone can file" on public.copyright_claims
  for insert with check (status = 'open' and resolved_at is null and resolved_by is null);

-- ============ 6. Notifications: users may only mark read, nothing else ============
revoke update on public.notifications from anon, authenticated;
grant update (read_at) on public.notifications to authenticated;

-- ============ 7. Upload rate limits (daily/monthly), from platform_settings ============
-- These settings existed but were never enforced. Also caps AI-moderation cost abuse.
create or replace function public.enforce_upload_limits()
returns trigger language plpgsql security definer set search_path = public as $$
declare daily_limit int; monthly_limit int; day_count int; month_count int;
begin
  daily_limit := coalesce((select (value::text)::int from public.platform_settings where key = 'daily_upload_limit'), 10);
  monthly_limit := coalesce((select (value::text)::int from public.platform_settings where key = 'monthly_upload_limit'), 150);
  select count(*) into day_count from public.uploads
    where user_id = new.user_id and created_at > now() - interval '1 day';
  select count(*) into month_count from public.uploads
    where user_id = new.user_id and created_at > now() - interval '30 days';
  if day_count >= daily_limit then
    raise exception 'Daily upload limit of % reached. Try again tomorrow.', daily_limit;
  end if;
  if month_count >= monthly_limit then
    raise exception 'Monthly upload limit of % reached.', monthly_limit;
  end if;
  return new;
end;
$$;
revoke execute on function public.enforce_upload_limits() from public, anon, authenticated;

drop trigger if exists on_upload_limits on public.uploads;
create trigger on_upload_limits before insert on public.uploads
  for each row execute function public.enforce_upload_limits();

-- ============ 8. Storage bucket: size + type limits ============
update storage.buckets
  set file_size_limit = 52428800,
      allowed_mime_types = array['image/jpeg','image/png','video/mp4','video/quicktime','video/webm']
  where id = 'uploads';

commit;
