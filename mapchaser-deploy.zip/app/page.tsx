// @ts-nocheck -- this page embeds a self-contained, already-tested vanilla JS/CSS
// interactive experience (cinematic intro, custom cursor, world map) rather than
// idiomatic React state. Runtime logic is unaffected; only static type-checking
// is skipped for this file.
"use client";
import { useEffect, useRef } from "react";

const PAGE_CSS = `:root{
--green:#12372A;--gold:#D6A85F;--ivory:#F5F0E6;--sage:#7E8F76;--sand:#B08B63;--blue:#527C82;--ink:#17201C;
--line:#E2DACB;--card:#FFFFFF;
--display:'Space Grotesk',system-ui,sans-serif;--mono:'Space Mono',monospace;--sans:'DM Sans',system-ui,sans-serif;
box-sizing:border-box;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)
}
*,*::before,*::after{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;background:var(--ivory);color:var(--ink);font-family:var(--sans);overflow-x:hidden}
h1,h2{font-family:var(--display);font-weight:600;margin:0;letter-spacing:-.01em}
.mono{font-family:var(--mono)}
a{color:inherit}
:focus-visible{outline:2px solid var(--green);outline-offset:3px}
.wrap{max-width:1180px;margin:0 auto;padding:0 24px}
.btn{display:inline-flex;align-items:center;gap:10px;padding:15px 28px;border-radius:2px;font-family:var(--display);font-weight:600;font-size:.84rem;letter-spacing:.06em;text-transform:uppercase;text-decoration:none;border:1.5px solid transparent;cursor:pointer;transition:transform .25s cubic-bezier(.2,.8,.2,1),background .2s}
.btn.p{background:var(--green);color:var(--ivory)}
.btn.p:hover{background:#0d2a1f}
.btn.g{border-color:var(--ink);color:var(--ink)}
.btn.g:hover{background:var(--ink);color:var(--ivory)}
@media(hover:hover){.btn:hover{transform:translateY(-2px)}}
.btn:active{transform:scale(.97)}

/* custom cursor */
.cx{position:fixed;top:0;left:0;width:7px;height:7px;border-radius:50%;background:var(--green);pointer-events:none;z-index:999;transform:translate(-50%,-50%);transition:opacity .2s}
.cx.ring{width:32px;height:32px;background:none;border:1px solid var(--green);transition:width .25s,height .25s,opacity .2s}
.cx.big{width:56px;height:56px;border-color:var(--gold)}
@media(hover:none),(max-width:860px){.cx{display:none}}

/* intro */
#intro{position:fixed;inset:0;z-index:200;background:var(--ivory);display:flex;align-items:center;justify-content:center;flex-direction:column;gap:18px;transition:opacity .6s ease,visibility 0s .6s}
#intro.hide{opacity:0;visibility:hidden}
#intro .coord{font-family:var(--mono);font-size:.82rem;letter-spacing:.08em;color:var(--sand);opacity:0;animation:fade .6s ease forwards .2s}
#intro svg{width:160px;height:40px;opacity:0;animation:fade .4s ease forwards .7s}
#intro path{stroke-dasharray:220;stroke-dashoffset:220;animation:draw 1s ease forwards .8s}
#intro .word{font-family:var(--display);font-weight:700;font-size:1.3rem;letter-spacing:.22em;color:var(--ink);opacity:0;animation:fade .6s ease forwards 1.7s}
#intro .skip{position:absolute;bottom:28px;background:none;border:1px solid var(--line);color:var(--sand);font-family:var(--mono);font-size:.68rem;letter-spacing:.06em;text-transform:uppercase;padding:8px 16px;border-radius:2px;cursor:pointer}
@keyframes fade{to{opacity:1}}
@keyframes draw{to{stroke-dashoffset:0}}

/* nav */
header.nav{position:fixed;top:0;left:0;right:0;z-index:100;padding:22px 0;transition:padding .4s cubic-bezier(.2,.8,.2,1)}
header.nav .bar{position:relative;overflow:hidden;display:flex;align-items:center;justify-content:space-between;transition:background .4s,padding .4s,border-radius .4s,box-shadow .4s,border-color .4s}
header.nav.scrolled{padding:12px 0}
header.nav.scrolled .bar{
background:linear-gradient(180deg,rgba(255,255,255,.05),rgba(255,255,255,0) 40%),rgba(8,9,10,.78);
backdrop-filter:blur(18px) saturate(160%);-webkit-backdrop-filter:blur(18px) saturate(160%);
border:1px solid rgba(255,255,255,.1);border-radius:999px;padding:9px 10px 9px 24px;
box-shadow:0 24px 60px -24px rgba(0,0,0,.65),inset 0 1px 0 rgba(255,255,255,.1)}
header.nav.scrolled .bar::before{content:"";position:absolute;inset:0;background:linear-gradient(115deg,rgba(255,255,255,.14),transparent 35%);pointer-events:none}
.brand{position:relative;z-index:1;font-family:var(--display);font-weight:700;font-size:1.02rem;letter-spacing:.16em;text-decoration:none;color:var(--ink);transition:color .4s}
header.nav.scrolled .brand{color:var(--ivory)}
.navlinks{position:relative;z-index:1;display:flex;align-items:center;gap:28px}
.navlinks a:not(.btn){font-family:var(--mono);font-size:.72rem;letter-spacing:.06em;text-transform:uppercase;text-decoration:none;color:var(--ink);opacity:.72;position:relative;padding-bottom:4px;transition:color .4s}
header.nav.scrolled .navlinks a:not(.btn){color:var(--ivory)}
.navlinks a:not(.btn)::after{content:"";position:absolute;left:50%;bottom:-2px;width:4px;height:4px;border-radius:50%;background:var(--gold);opacity:0;transform:translate(-50%,4px);transition:opacity .2s,transform .2s}
.navlinks a:not(.btn):hover{opacity:1}
.navlinks a:not(.btn):hover::after{opacity:1;transform:translate(-50%,0)}
.navlinks .acts{display:flex;align-items:center;gap:16px;margin-left:8px}
.navlinks .acts a:not(.btn){display:none}
@media(min-width:760px){.navlinks .acts a:not(.btn){display:inline}}
.burger{position:relative;z-index:1;display:none;width:44px;height:44px;border-radius:50%;border:1px solid var(--line);background:none;place-content:center;cursor:pointer;transition:border-color .4s}
.burger span{display:block;width:18px;height:1.5px;background:var(--ink);margin:4px auto;transition:background .4s}
header.nav.scrolled .burger{border-color:rgba(255,255,255,.25)}
header.nav.scrolled .burger span{background:var(--ivory)}
@media(max-width:759px){.navlinks{display:none}.burger{display:grid}}

#mnav{position:fixed;inset:0;z-index:150;background:var(--ivory);display:flex;flex-direction:column;justify-content:center;gap:24px;padding:40px;transform:translateY(-100%);transition:transform .5s cubic-bezier(.2,.9,.2,1)}
#mnav.open{transform:none}
#mnav a{font-family:var(--display);font-weight:600;font-size:1.9rem;text-decoration:none;color:var(--ink);text-transform:uppercase}
#mnav .close{position:absolute;top:22px;right:24px;width:44px;height:44px;border-radius:50%;border:1px solid var(--line);background:none;color:var(--ink);font-size:1.4rem}

/* hero */
.hero{position:relative;min-height:100svh;display:flex;align-items:flex-end;padding-bottom:10vh;overflow:hidden;background:var(--ivory)}
.hero .contours{position:absolute;inset:-10%;opacity:.5;animation:drift 90s linear infinite alternate}
@keyframes drift{to{transform:translate(2%,-2%)}}
.hero .in{position:relative;z-index:2;max-width:820px}
.hero .coord{font-family:var(--mono);font-size:.8rem;color:var(--sand);letter-spacing:.08em;display:block;margin-bottom:18px}
.hero h1{font-size:clamp(2.6rem,8.2vw,5.6rem);line-height:.98;text-transform:uppercase;color:var(--ink)}
.hero h1 span{color:var(--green)}
.hero p.sub{max-width:46ch;color:#4b564e;font-size:1.05rem;margin:22px 0 32px;line-height:1.6}
.hero .cta{display:flex;gap:14px;flex-wrap:wrap}
.scrollcue{position:absolute;left:50%;bottom:28px;translate:-50% 0;display:flex;flex-direction:column;align-items:center;gap:8px;color:var(--sand);font-family:var(--mono);font-size:.66rem;letter-spacing:.12em;z-index:2}
.scrollcue i{width:1px;height:38px;background:linear-gradient(var(--sand),transparent);display:block}
.js .rv{opacity:0;translate:0 24px;transition:opacity .8s ease var(--d,0ms),translate .8s ease var(--d,0ms)}
.js .rv.vis{opacity:1;translate:none}

/* map section */
.mapsec{position:relative;padding:14vh 0;background:var(--card);border-top:1px solid var(--line)}
.mapsec .head{text-align:center;max-width:620px;margin:0 auto 60px}
.mapsec .eyebrow{font-family:var(--mono);font-size:.72rem;letter-spacing:.16em;text-transform:uppercase;color:var(--sand)}
.mapsec h2{font-size:clamp(1.7rem,4.2vw,2.7rem);margin-top:14px;text-transform:uppercase;color:var(--ink)}
.mapsec .head p{color:#5a655c;margin-top:14px}
.mapstage{position:relative;max-width:980px;margin:0 auto;aspect-ratio:16/11}
.mapstage svg{width:100%;height:100%;overflow:visible}
.contourbg{stroke:#D9D1BF;fill:none;stroke-width:1}
.route{fill:none;stroke:var(--sand);stroke-width:1.3;stroke-dasharray:6 6;opacity:.65}
.pt{cursor:pointer}
.pt circle.core{fill:var(--green)}
.pt circle.pulse{fill:none;stroke:var(--green);stroke-width:1;opacity:.5;animation:pulse 2.6s ease-out infinite}
.pt.on circle.core{fill:var(--gold)}
@keyframes pulse{0%{r:5;opacity:.6}100%{r:16;opacity:0}}
.pt text{font-family:var(--mono);font-size:9px;fill:#5a655c;text-transform:uppercase;letter-spacing:.04em}
.pt:hover text,.pt.on text{fill:var(--ink)}

.detail{position:absolute;inset:auto 0 -6% 0;margin:0 auto;max-width:420px;background:var(--card);border:1px solid var(--line);border-radius:2px;padding:22px 26px;opacity:0;visibility:hidden;translate:0 16px;box-shadow:0 20px 50px -28px rgba(23,32,28,.3);transition:opacity .4s ease,translate .4s ease,visibility 0s .4s}
.detail.show{opacity:1;visibility:visible;translate:0 0;transition:opacity .4s ease,translate .4s ease}
.detail .coord{font-family:var(--mono);font-size:.7rem;color:var(--sand);letter-spacing:.06em}
.detail h3{font-family:var(--display);font-weight:600;font-size:1.3rem;margin-top:6px;text-transform:uppercase;color:var(--ink)}
.detail p{color:#5a655c;font-size:.9rem;margin-top:8px}
.detail a{display:inline-block;margin-top:14px;font-family:var(--mono);font-size:.72rem;letter-spacing:.06em;text-transform:uppercase;color:var(--green);text-decoration:underline}
.hint{text-align:center;color:#8a8f84;font-family:var(--mono);font-size:.7rem;letter-spacing:.06em;margin-top:28px;text-transform:uppercase}

@media(max-width:760px){.mapstage{display:none}}
.mobilecards{display:none}
@media(max-width:760px){.mobilecards{display:grid;gap:10px}}
.mcard{background:var(--card);border:1px solid var(--line);border-radius:2px;padding:16px 18px;display:flex;justify-content:space-between;align-items:center;text-decoration:none;color:var(--ink)}
.mcard .coord{display:block;font-family:var(--mono);font-size:.66rem;color:var(--sand);margin-top:4px}
.mcard b{font-family:var(--display);font-weight:600;text-transform:uppercase;font-size:1rem}
.mcard span.arrow{color:var(--green);font-family:var(--mono)}

/* destinations — editorial expedition layout */
.destsec{padding:14vh 0;background:var(--ivory);border-top:1px solid var(--line)}
.destsec .head{text-align:center;max-width:620px;margin:0 auto 70px}
.destsec .eyebrow{font-family:var(--mono);font-size:.72rem;letter-spacing:.16em;text-transform:uppercase;color:var(--sand)}
.destsec h2{font-size:clamp(1.7rem,4.2vw,2.7rem);margin-top:14px;text-transform:uppercase;color:var(--ink)}
.destsec .head p{color:#5a655c;margin-top:14px}
.destlist{position:relative}
.destlist::before{content:"";position:absolute;left:35px;top:0;bottom:0;width:1px;background:repeating-linear-gradient(to bottom,var(--sand) 0 6px,transparent 6px 13px);z-index:0}
.drow{position:relative;z-index:1;display:flex;gap:40px;align-items:center;padding:56px 0;border-top:1px solid var(--line)}
.drow:first-child{border-top:none;padding-top:0}
.dnum{flex:none;width:70px;font-family:var(--display);font-weight:700;font-size:2.1rem;line-height:1;color:transparent;-webkit-text-stroke:1.4px var(--ink);opacity:.3;position:relative;text-align:center}
.dnum::after{content:"";position:absolute;left:50%;top:50%;width:7px;height:7px;border-radius:50%;background:var(--gold);translate:-50% -50%;box-shadow:0 0 0 5px var(--ivory)}
.dtext{flex:1 1 320px;min-width:0}
.dtext .coord{display:block;font-family:var(--mono);font-size:.74rem;color:var(--sand);letter-spacing:.06em;margin-bottom:10px}
.dtext h3{font-family:var(--display);font-weight:600;font-size:clamp(1.5rem,3.4vw,2.3rem);text-transform:uppercase;color:var(--ink)}
.dtext p{color:#5a655c;margin-top:10px;max-width:36ch;line-height:1.6}
.dtext a{display:inline-block;margin-top:18px;font-family:var(--mono);font-size:.72rem;letter-spacing:.06em;text-transform:uppercase;color:var(--green);text-decoration:underline}
.dimg{flex:1 1 360px;aspect-ratio:4/3;border-radius:2px;position:relative;overflow:hidden;background:var(--g);min-width:0;transition:transform .5s cubic-bezier(.2,.8,.2,1)}
.dimg svg{position:absolute;inset:0;width:100%;height:100%;opacity:.3}
.dimg .corner{position:absolute;bottom:14px;right:16px;font-family:var(--mono);font-size:.7rem;color:rgba(245,240,230,.9);letter-spacing:.05em}
@media(hover:hover){.drow:hover .dimg{transform:scale(1.02)}}
.drow:nth-child(even) .dtext{order:2}
.drow:nth-child(even) .dimg{order:1}
@media(max-width:820px){
.destlist::before{left:17px}
.drow{flex-direction:column;align-items:flex-start;gap:18px}
.drow:nth-child(even) .dtext{order:0}
.drow:nth-child(even) .dimg{order:0}
.dnum{width:34px;font-size:1.3rem;text-align:left}
.dnum::after{left:17px;translate:-50% -50%}
.dimg{width:100%}
}

footer{padding:40px 0;text-align:center;color:#8a8f84;font-family:var(--mono);font-size:.7rem;letter-spacing:.06em;border-top:1px solid var(--line);background:var(--ivory)}
@media(prefers-reduced-motion:reduce){*{animation-duration:.01ms!important;transition-duration:.01ms!important}.hero .contours{animation:none}.js .rv{opacity:1;translate:none}}
/* how it works */
.howsec{padding:14vh 0;background:var(--card);border-top:1px solid var(--line)}
.howsec .head{text-align:center;max-width:620px;margin:0 auto 60px}
.howsec .eyebrow{font-family:var(--mono);font-size:.72rem;letter-spacing:.16em;text-transform:uppercase;color:var(--sand)}
.howsec h2{font-size:clamp(1.7rem,4.2vw,2.7rem);margin-top:14px;text-transform:uppercase;color:var(--ink)}
.howsec .head p{color:#5a655c;margin-top:14px}
.howsteps{display:grid;gap:14px;grid-template-columns:repeat(auto-fit,minmax(170px,1fr))}
.howstep{padding:22px 18px;border:1px solid var(--line);border-radius:2px;background:var(--ivory)}
.howstep b{font-family:var(--display);font-weight:700;color:var(--gold);font-size:1.3rem}
.howstep h3{font-family:var(--display);font-weight:600;text-transform:uppercase;font-size:1.05rem;margin-top:8px;color:var(--ink)}
.howstep p{color:#5a655c;font-size:.88rem;margin-top:8px;line-height:1.5}

/* rewards */
.rewardsec{padding:14vh 0;background:var(--ivory)}
.rewardsec .head{text-align:center;max-width:620px;margin:0 auto 50px}
.rewardsec .eyebrow{font-family:var(--mono);font-size:.72rem;letter-spacing:.16em;text-transform:uppercase;color:var(--sand)}
.rewardsec h2{font-size:clamp(1.7rem,4.2vw,2.7rem);margin-top:14px;text-transform:uppercase;color:var(--ink)}
.rewardsec .head p{color:#5a655c;margin-top:14px}
.milestone{max-width:320px;margin:0 auto;background:var(--card);border:1px solid var(--line);border-radius:2px;padding:28px}
.mrow{display:flex;align-items:center;gap:12px;padding:9px 0;font-family:var(--mono);font-size:.82rem;text-transform:uppercase;letter-spacing:.04em;color:var(--ink)}
.mrow i{width:9px;height:9px;border-radius:50%;background:var(--green);flex:none}
.mpoints{text-align:center;margin-top:16px;padding-top:16px;border-top:1px solid var(--line);font-family:var(--display);font-weight:700;font-size:2.2rem;color:var(--gold)}
.mpoints small{display:block;font-family:var(--mono);font-size:.62rem;letter-spacing:.1em;color:#8a8f84;margin-top:2px}
.rewardsec .hint{text-align:center;color:#8a8f84;font-family:var(--mono);font-size:.72rem;letter-spacing:.04em;margin-top:24px;max-width:48ch;margin-left:auto;margin-right:auto}
`;
const PAGE_HTML = `
<div class="cx" id="cxDot"></div>
<div class="cx ring" id="cxRing"></div>

<div id="intro" role="status" aria-label="Loading Map Chaser">
<span class="coord mono">28.6139° N&nbsp;&nbsp;77.2090° E</span>
<svg viewBox="0 0 160 40"><path d="M5 30 Q40 5 80 20 T155 10" stroke="#B08B63" stroke-width="1.4" fill="none"/></svg>
<span class="word">MAP CHASER</span>
<button class="skip" id="skipIntro">Skip intro</button>
</div>

<header class="nav" id="siteNav">
<div class="wrap bar">
<a class="brand" href="#top">MAP CHASER</a>
<nav class="navlinks" aria-label="Primary">
<a href="#map">World Map</a>
<a href="#destinations">Destinations</a>
<a href="#how">How It Works</a>
<a href="#rewards">Rewards</a>
<div class="acts">
<a href="/login">Login</a>
<a class="btn p" href="/login" style="padding:10px 20px;font-size:.72rem">Start Your Chase</a>
</div>
</nav>
<button class="burger" id="burgerBtn" aria-label="Open menu" aria-expanded="false" aria-controls="mnav"><span></span><span></span><span></span></button>
</div>
</header>

<nav id="mnav" aria-label="Mobile">
<button class="close" id="mnavClose" aria-label="Close menu">&times;</button>
<a href="#map">World Map</a>
<a href="#destinations">Destinations</a>
<a href="#how">How It Works</a>
<a href="#rewards">Rewards</a>
<a href="/login">Login</a>
<a href="/login" style="color:var(--green)">Start Your Chase →</a>
</nav>

<main id="top">
<section class="hero">
<svg class="contours" viewBox="0 0 800 600" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
<g class="contourbg">
<path d="M-50 500 Q150 420 350 480 T800 440"/>
<path d="M-50 440 Q180 360 380 420 T800 380"/>
<path d="M-50 560 Q130 500 330 540 T800 500"/>
<path d="M-50 160 Q220 80 420 140 T850 100"/>
<path d="M-50 220 Q200 150 420 200 T850 170"/>
</g>
</svg>
<div class="wrap in">
<span class="coord rv">28.6139° N / 77.2090° E — EXPEDITION 001</span>
<h1 class="rv" style="--d:80ms">Chase<br>the <span>Unknown.</span></h1>
<p class="sub rv" style="--d:160ms">Discover extraordinary places, capture your journey, and earn rewards for authentic travel experiences.</p>
<div class="cta rv" style="--d:240ms">
<a class="btn p" href="#map">Explore the World →</a>
<a class="btn g" href="/login">Start Your Chase →</a>
</div>
</div>
<div class="scrollcue"><span>Scroll</span><i></i></div>
</section>

<section class="mapsec" id="map">
<div class="wrap">
<div class="head rv">
<span class="eyebrow">The World Map</span>
<h2>Every chase begins with a point on the map</h2>
<p>Select a destination to uncover its story.</p>
</div>

<div class="mapstage rv">
<svg viewBox="0 0 900 560" aria-hidden="false" role="img" aria-label="Interactive map of destinations">
<g class="contourbg">
<ellipse cx="450" cy="280" rx="420" ry="250"/>
<ellipse cx="450" cy="280" rx="330" ry="195"/>
<ellipse cx="450" cy="280" rx="240" ry="140"/>
</g>
<path class="route" id="routePath" d="M160,150 C260,110 320,230 400,200 S520,120 560,240 S700,260 760,180 M400,200 C380,280 330,330 300,400 M560,240 C600,320 560,380 480,420"/>
<g id="points"></g>
</svg>
<div class="detail" id="detail">
<span class="coord" id="dCoord"></span>
<h3 id="dName"></h3>
<p id="dLine"></p>
<a href="/login" id="dLink">Explore This Route →</a>
</div>
</div>
<p class="hint rv">Tap a glowing point to reveal its story</p>

<div class="mobilecards rv" id="mcards"></div>
</div>
</section>

<section class="destsec" id="destinations">
<div class="wrap">
<div class="head rv">
<span class="eyebrow">The Expedition</span>
<h2>Seven routes worth chasing</h2>
<p>Each destination is a chapter. Every chapter leads to the next.</p>
</div>
<div class="destlist" id="destlist"></div>
</div>
</section>

<section class="howsec" id="how">
<div class="wrap">
<div class="head rv">
<span class="eyebrow">How It Works</span>
<h2>Six steps. One honest loop.</h2>
<p>No feeds, no guesswork — just a clear path from a moment captured to a reward earned.</p>
</div>
<div class="howsteps">
<div class="howstep rv" style="--d:0ms"><b>01</b><h3>Discover</h3><p>Browse real places through real journeys.</p></div>
<div class="howstep rv" style="--d:60ms"><b>02</b><h3>Chase</h3><p>Pick a destination worth the trip.</p></div>
<div class="howstep rv" style="--d:120ms"><b>03</b><h3>Capture</h3><p>Take an original photo or video there.</p></div>
<div class="howstep rv" style="--d:180ms"><b>04</b><h3>Verify</h3><p>Security, quality, safety and originality checks run first.</p></div>
<div class="howstep rv" style="--d:240ms"><b>05</b><h3>Review</h3><p>A person decides when the system isn't sure.</p></div>
<div class="howstep rv" style="--d:300ms"><b>06</b><h3>Earn</h3><p>Approved work earns points — never before.</p></div>
</div>
</div>
</section>

<section class="rewardsec" id="rewards">
<div class="wrap">
<div class="head rv">
<span class="eyebrow">Rewards</span>
<h2>Milestones, not promises</h2>
<p>Points reward approved, original contributions — never views, streaks or luck.</p>
</div>
<div class="milestone rv">
<div class="mrow"><i></i><span>Captured</span></div>
<div class="mrow"><i></i><span>Verified</span></div>
<div class="mrow"><i></i><span>Approved</span></div>
<div class="mpoints">+250 <small>POINTS</small></div>
</div>
<p class="hint rv">Rewards are not guaranteed income. Conversion rate, limits and fees are always shown before you redeem.</p>
<div class="cta rv" style="justify-content:center;margin-top:28px">
<a class="btn p" href="/explore">See Approved Journeys →</a>
<a class="btn g" href="/login">Start Earning →</a>
</div>
</div>
</section>

</main>

<footer>MAP CHASER — CHASE PLACES. CAPTURE MOMENTS. EARN REWARDS.</footer>
`;

export default function Home() {
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
const DESTS=[
{name:"Himalayas",coord:"30.0668° N / 79.0193° E",line:"Where the mountains begin.",x:470,y:150},
{name:"Himachal",coord:"31.1048° N / 77.1734° E",line:"Pine ridges above the clouds.",x:420,y:190},
{name:"Rajasthan",coord:"27.0238° N / 74.2179° E",line:"Gold light on ancient stone.",x:300,y:230},
{name:"Kerala",coord:"09.9312° N / 76.2673° E",line:"Green water, slow days.",x:360,y:400},
{name:"Goa",coord:"15.2993° N / 74.1240° E",line:"Coastline chasing the sun.",x:300,y:340},
{name:"Northeast",coord:"26.2006° N / 92.9376° E",line:"Clouds caught in the hills.",x:650,y:210},
{name:"International",coord:"VARIES / VARIES",line:"Beyond the home trail.",x:760,y:160},
];
const d=document,q=s=>d.querySelector(s),qa=s=>[...d.querySelectorAll(s)];
const rm=matchMedia('(prefers-reduced-motion:reduce)').matches;
d.documentElement.classList.add('js');

/* intro */
const intro=q('#intro');
function closeIntro(){intro.classList.add('hide')}
if(rm){closeIntro();}else{setTimeout(closeIntro,2600);}
q('#skipIntro').addEventListener('click',closeIntro);

/* custom cursor */
if(matchMedia('(hover:hover)').matches){
const dot=q('#cxDot'),ring=q('#cxRing');
addEventListener('pointermove',e=>{
dot.style.left=e.clientX+'px';dot.style.top=e.clientY+'px';
ring.style.left=e.clientX+'px';ring.style.top=e.clientY+'px';
});
qa('a,button').forEach(el=>{
el.addEventListener('mouseenter',()=>ring.classList.add('big'));
el.addEventListener('mouseleave',()=>ring.classList.remove('big'));
});
}

/* nav */
const nav=q('#siteNav');
addEventListener('scroll',()=>nav.classList.toggle('scrolled',scrollY>30),{passive:true});
const burger=q('#burgerBtn'),mnav=q('#mnav');
function menu(o){mnav.classList.toggle('open',o);burger.setAttribute('aria-expanded',o);d.body.style.overflow=o?'hidden':''}
burger.addEventListener('click',()=>menu(true));
q('#mnavClose').addEventListener('click',()=>menu(false));
qa('#mnav a').forEach(a=>a.addEventListener('click',()=>menu(false)));
qa('[data-soon]').forEach(a=>a.addEventListener('click',e=>e.preventDefault()));

/* reveal on scroll */
if(!rm){const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('vis');io.unobserve(e.target)}}),{threshold:.15});
qa('.rv').forEach(e=>io.observe(e));}else{qa('.rv').forEach(e=>e.classList.add('vis'));}

/* route draw on view */
const routeEl=q('#routePath');
if(!rm){
const len=routeEl.getTotalLength();
routeEl.style.strokeDasharray=len;routeEl.style.strokeDashoffset=len;
new IntersectionObserver((es,ob)=>es.forEach(e=>{if(e.isIntersecting){
routeEl.style.transition='stroke-dashoffset 2.2s ease';routeEl.style.strokeDashoffset=0;ob.disconnect();
}}),{threshold:.3}).observe(q('.mapstage'));
}

/* map points */
const svg=q('#points'),detail=q('#detail');
DESTS.forEach((dst)=>{
const g=document.createElementNS('http://www.w3.org/2000/svg','g');
g.setAttribute('class','pt');g.setAttribute('tabindex','0');g.setAttribute('role','button');
g.setAttribute('aria-label','View '+dst.name);
g.innerHTML=`<circle class="pulse" cx="${dst.x}" cy="${dst.y}" r="5"></circle><circle class="core" cx="${dst.x}" cy="${dst.y}" r="4"></circle><text x="${dst.x+10}" y="${dst.y+4}">${dst.name}</text>`;
function activate(){
qa('.pt').forEach(p=>p.classList.remove('on'));g.classList.add('on');
q('#dCoord').textContent=dst.coord;q('#dName').textContent=dst.name;q('#dLine').textContent=dst.line;
q('#dLink').href='/explore?q='+encodeURIComponent(dst.name);
detail.classList.add('show');
}
g.addEventListener('click',activate);
g.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();activate();}});
svg.appendChild(g);
});

/* mobile cards */
const mc=q('#mcards');
DESTS.forEach(dst=>{
const a=document.createElement('a');
a.href='/explore?q='+encodeURIComponent(dst.name);a.className='mcard';
a.innerHTML=`<span><b>${dst.name}</b><span class="coord">${dst.coord}</span></span><span class="arrow">→</span>`;
mc.appendChild(a);
});

/* destinations — editorial expedition rows */
const DESTLONG=[
{name:"Himalayas",coord:"30.0668° N / 79.0193° E",line:"Where the mountains begin.",g:"linear-gradient(160deg,#527C82,#2b454a)"},
{name:"Kerala",coord:"09.9312° N / 76.2673° E",line:"Green water, slow days.",g:"linear-gradient(160deg,#12372A,#2f5c45)"},
{name:"Goa",coord:"15.2993° N / 74.1240° E",line:"Coastline chasing the sun.",g:"linear-gradient(160deg,#3a6166,#B08B63)"},
{name:"Rajasthan",coord:"27.0238° N / 74.2179° E",line:"Gold light on ancient stone.",g:"linear-gradient(160deg,#B08B63,#D6A85F)"},
{name:"Northeast",coord:"26.2006° N / 92.9376° E",line:"Clouds caught in the hills.",g:"linear-gradient(160deg,#1d4433,#7E8F76)"},
{name:"Himachal",coord:"31.1048° N / 77.1734° E",line:"Pine ridges above the clouds.",g:"linear-gradient(160deg,#2f4d3a,#A8B8A0)"},
{name:"International",coord:"VARIES / VARIES",line:"Beyond the home trail.",g:"linear-gradient(160deg,#17201C,#5a655c)"},
];
const destlist=q('#destlist');
DESTLONG.forEach((dst,i)=>{
const row=document.createElement('article');
row.className='drow rv';row.style.setProperty('--d',(i*40)+'ms');
row.innerHTML=`
<div class="dnum">${String(i+1).padStart(2,'0')}</div>
<div class="dtext">
<span class="coord">${dst.coord}</span>
<h3>${dst.name}</h3>
<p>${dst.line}</p>
<a href="#map">View on the map →</a>
</div>
<div class="dimg" style="background:${dst.g}">
<svg viewBox="0 0 300 220" preserveAspectRatio="none" aria-hidden="true">
<g fill="none" stroke="#F5F0E6" stroke-width="1">
<ellipse cx="150" cy="110" rx="130" ry="80"/>
<ellipse cx="150" cy="110" rx="90" ry="54"/>
<ellipse cx="150" cy="110" rx="50" ry="28"/>
</g>
</svg>
<span class="corner">${dst.coord.split(' / ')[0]}</span>
</div>`;
destlist.appendChild(row);
});
if(!rm){const io2=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('vis');io2.unobserve(e.target)}}),{threshold:.1});
qa('#destlist .rv').forEach(e=>io2.observe(e));}else{qa('#destlist .rv').forEach(e=>e.classList.add('vis'));}
  }, []);

  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: PAGE_CSS }} />
      <div ref={rootRef} dangerouslySetInnerHTML={{ __html: PAGE_HTML }} />
    </>
  );
}
