import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import SiteNav from "@/components/site-nav";
import WithdrawForm from "./withdraw-form";

export default async function WithdrawPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login?next=/withdraw");

  const { data: me } = await supabase.from("profiles").select("date_of_birth").eq("id", user.id).single();
  if (me && !me.date_of_birth) redirect("/complete-profile");

  const [{ data: wallet }, { data: settings }, { data: history }] = await Promise.all([
    supabase.from("wallets").select("available_points, locked_points").eq("user_id", user.id).single(),
    supabase.from("platform_settings").select("key, value").in("key", ["min_redeem_points", "conversion_rate_points_per_unit"]),
    supabase.from("withdrawals").select("*").eq("user_id", user.id).order("requested_at", { ascending: false }),
  ]);

  const minPoints = Number(settings?.find((s) => s.key === "min_redeem_points")?.value ?? 1000);
  const rate = Number(settings?.find((s) => s.key === "conversion_rate_points_per_unit")?.value ?? 10);
  const available = wallet?.available_points ?? 0;

  return (
    <>
      <SiteNav />
      <main className="wrap">
        <span style={{ fontFamily: "var(--mono)", fontSize: ".72rem", letterSpacing: ".1em", color: "var(--sand)", textTransform: "uppercase" }}>
          Redemption
        </span>
        <h1 style={{ marginTop: 10 }}>Redeem Your Points</h1>
        <p className="muted">
          Conversion value, fees and the final amount are shown before you confirm. Points are locked the moment
          you request — they return to your balance automatically if the request is rejected or cancelled.
        </p>

        {available < minPoints ? (
          <div className="card">
            <p className="muted">
              You need at least {minPoints} available points to redeem. You currently have {available}.
            </p>
          </div>
        ) : (
          <WithdrawForm available={available} minPoints={minPoints} rate={rate} />
        )}

        <div className="card">
          <h2>History</h2>
          {!history?.length && <p className="muted">No redemption requests yet.</p>}
          {!!history?.length && (
            <table>
              <thead>
                <tr><th>Requested</th><th>Points</th><th>Method</th><th>Final Amount</th><th>Status</th></tr>
              </thead>
              <tbody>
                {history.map((w) => (
                  <tr key={w.id}>
                    <td>{new Date(w.requested_at).toLocaleDateString()}</td>
                    <td>{w.points}</td>
                    <td>{w.payment_method.replace("_", " ")}</td>
                    <td>₹{Number(w.final_amount).toFixed(2)}</td>
                    <td><span className={`pill ${w.status === "completed" ? "approved" : ["rejected","cancelled"].includes(w.status) ? "rejected" : "pending"}`}>{w.status}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </main>
    </>
  );
}
