"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function WithdrawForm({
  available, minPoints, rate,
}: { available: number; minPoints: number; rate: number }) {
  const router = useRouter();
  const supabase = createClient();
  const [points, setPoints] = useState(minPoints);
  const [method, setMethod] = useState<"bank_transfer" | "upi" | "gift_voucher">("upi");
  const [detail, setDetail] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ type: "err" | "ok"; text: string } | null>(null);

  const estValue = (points / Math.max(rate, 1)).toFixed(2);
  const estFee = method === "bank_transfer" ? 5 : 0;
  const estFinal = Math.max(Number(estValue) - estFee, 0).toFixed(2);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    if (!detail) {
      setMsg({ type: "err", text: "Add your payout details (UPI ID / account / email)." });
      return;
    }
    setBusy(true);
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) { router.push("/login"); return; }

      const { error } = await supabase.from("withdrawals").insert({
        user_id: user.id,
        points,
        payment_method: method,
        payment_details: { detail },
      });
      if (error) throw error;

      setMsg({ type: "ok", text: "Requested. Your points are now locked until this is processed." });
      router.refresh();
    } catch (err: any) {
      setMsg({ type: "err", text: err.message ?? "Could not submit the request." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className="card" onSubmit={handleSubmit}>
      <label htmlFor="pts">Points to Redeem</label>
      <input
        id="pts" type="number" min={minPoints} max={available} value={points}
        onChange={(e) => setPoints(Number(e.target.value))}
      />
      <p className="muted" style={{ fontSize: ".8rem", marginTop: 6 }}>
        Minimum {minPoints} · Available {available}
      </p>

      <label htmlFor="method">Payout Method</label>
      <select id="method" value={method} onChange={(e) => setMethod(e.target.value as any)}>
        <option value="upi">UPI</option>
        <option value="bank_transfer">Bank Transfer</option>
        <option value="gift_voucher">Gift Voucher</option>
      </select>

      <label htmlFor="detail">
        {method === "upi" ? "UPI ID" : method === "bank_transfer" ? "Account Details" : "Email for Voucher"}
      </label>
      <input id="detail" value={detail} onChange={(e) => setDetail(e.target.value)} />

      <div style={{ marginTop: 16, paddingTop: 14, borderTop: "1px solid var(--line)" }}>
        <div className="row" style={{ justifyContent: "space-between", fontSize: ".88rem" }}>
          <span className="muted">Conversion value</span><span>₹{estValue}</span>
        </div>
        <div className="row" style={{ justifyContent: "space-between", fontSize: ".88rem" }}>
          <span className="muted">Provider fee</span><span>{estFee ? `−₹${estFee}` : "None"}</span>
        </div>
        <div className="row" style={{ justifyContent: "space-between", fontWeight: 700, marginTop: 4 }}>
          <span>You receive</span><span>₹{estFinal}</span>
        </div>
        <p className="muted" style={{ fontSize: ".78rem", marginTop: 8 }}>
          Exact amount is computed and locked server-side when you submit — this is an estimate.
        </p>
      </div>

      <button className="btn p" type="submit" disabled={busy || points < minPoints || points > available} style={{ marginTop: 16 }}>
        {busy ? "Submitting…" : "Request Redemption"}
      </button>

      {msg && <p className={msg.type === "err" ? "err" : "ok"} style={{ marginTop: 14 }}>{msg.text}</p>}
    </form>
  );
}
