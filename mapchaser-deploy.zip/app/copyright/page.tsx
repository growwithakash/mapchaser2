"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import SiteNav from "@/components/site-nav";
import { sendCopyrightAck } from "./actions";

export default function CopyrightPage() {
  const supabase = createClient();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [uploadId, setUploadId] = useState("");
  const [statement, setStatement] = useState("");
  const [evidence, setEvidence] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ type: "err" | "ok"; text: string } | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    if (!name || !email || !statement) {
      setMsg({ type: "err", text: "Name, email and a statement are required." });
      return;
    }
    setBusy(true);
    try {
      const { error } = await supabase.from("copyright_claims").insert({
        claimant_name: name,
        claimant_email: email,
        upload_id: uploadId || null,
        statement,
        evidence_url: evidence || null,
      });
      if (error) throw error;
      sendCopyrightAck(email, uploadId || null).catch(() => {});
      setMsg({ type: "ok", text: "Received. We review copyright claims and will contact you by email." });
      setName(""); setEmail(""); setUploadId(""); setStatement(""); setEvidence("");
    } catch (err: any) {
      setMsg({ type: "err", text: err.message ?? "Could not submit the claim. Try again." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
    <SiteNav />
    <main className="wrap">
      <span style={{ fontFamily: "var(--mono)", fontSize: ".72rem", letterSpacing: ".1em", color: "var(--sand)", textTransform: "uppercase" }}>
        Copyright
      </span>
      <h1 style={{ marginTop: 10 }}>File a Copyright Claim</h1>
      <p className="muted">
        If you believe content on Map Chaser infringes your copyright, describe it below. You do not need
        a Map Chaser account to file a claim. We review every claim and may temporarily hide the content
        while we investigate.
      </p>

      <form className="card" onSubmit={handleSubmit}>
        <label htmlFor="name">Your Name</label>
        <input id="name" value={name} onChange={(e) => setName(e.target.value)} required />

        <label htmlFor="email">Your Email</label>
        <input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />

        <label htmlFor="uid">Upload ID (If Known)</label>
        <input id="uid" value={uploadId} onChange={(e) => setUploadId(e.target.value)} placeholder="Optional — from the content's URL" />

        <label htmlFor="statement">Statement</label>
        <textarea
          id="statement"
          rows={4}
          value={statement}
          onChange={(e) => setStatement(e.target.value)}
          placeholder="Describe the work, where this copy appears, and confirm you are the rights holder or authorised to act on their behalf."
          required
        />

        <label htmlFor="evidence">Evidence Link (Optional)</label>
        <input id="evidence" value={evidence} onChange={(e) => setEvidence(e.target.value)} placeholder="Link to the original work" />

        <button className="btn p" type="submit" disabled={busy} style={{ marginTop: 18 }}>
          {busy ? "Submitting…" : "Submit Claim"}
        </button>

        {msg && (
          <p className={msg.type === "err" ? "err" : "ok"} style={{ marginTop: 14, fontFamily: "var(--sans)" }}>
            {msg.text}
          </p>
        )}
      </form>
    </main>
    </>
  );
}
