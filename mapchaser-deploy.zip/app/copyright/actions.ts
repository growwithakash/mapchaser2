"use server";
import { createAdminClient } from "@/lib/supabase/admin";
import { notify } from "@/lib/notifications/send";

/**
 * Public action (claimants have no account), so it must not be usable to make us
 * email arbitrary addresses: it only sends if a claim from that address was just
 * filed, and at most a few acknowledgments per address per hour.
 */
export async function sendCopyrightAck(email: string, uploadId: string | null) {
  let admin;
  try { admin = createAdminClient(); } catch { return; }

  const fiveMinAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();
  const { data: claim } = await admin
    .from("copyright_claims")
    .select("id")
    .eq("claimant_email", email)
    .gt("created_at", fiveMinAgo)
    .limit(1)
    .maybeSingle();
  if (!claim) return;

  const hourAgo = new Date(Date.now() - 60 * 60 * 1000).toISOString();
  const { count } = await admin
    .from("notifications")
    .select("*", { count: "exact", head: true })
    .eq("email", email)
    .eq("type", "copyright_received")
    .gt("created_at", hourAgo);
  if ((count ?? 0) >= 3) return;

  let uploadTitle = "";
  if (uploadId) {
    const { data } = await admin.from("uploads").select("title").eq("id", uploadId).maybeSingle();
    uploadTitle = data?.title ?? "";
  }
  await notify({ type: "copyright_received", email, data: { uploadTitle } });
}
