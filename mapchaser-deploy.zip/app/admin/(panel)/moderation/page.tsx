import { createClient } from "@/lib/supabase/server";
import { requireAdmin } from "@/lib/auth/require-admin";
import RowActions from "./row-actions";

export default async function ModerationPage() {
  await requireAdmin();
  const supabase = await createClient();
  const { data: uploads } = await supabase
    .from("uploads")
    .select("id, title, location, category, media_type, file_path, status, created_at, user_id")
    .in("status", ["pending", "manual_review"])
    .order("created_at", { ascending: true });

  const withUrls = await Promise.all(
    (uploads ?? []).map(async (u) => {
      const { data } = await supabase.storage.from("uploads").createSignedUrl(u.file_path, 3600);
      const { data: mod } = await supabase
        .from("moderation_results")
        .select("*")
        .eq("upload_id", u.id)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      return { ...u, url: data?.signedUrl ?? null, mod };
    })
  );

  return (
    <main className="wrap" style={{ maxWidth: 900 }}>
      <h1>Content Moderation</h1>
      <p className="muted">{withUrls.length} item(s) waiting. Oldest first.</p>

      {!withUrls.length && <div className="card"><p className="muted">Nothing pending — the queue is clear.</p></div>}

      {withUrls.map((u) => (
        <div key={u.id} className="card" style={{ display: "flex", gap: 16, alignItems: "flex-start" }}>
          <div style={{ width: 140, aspectRatio: "4/3", background: "var(--line)", flex: "none", borderRadius: 2, overflow: "hidden" }}>
            {u.url && u.media_type === "photo" && <img src={u.url} alt={u.title} style={{ width: "100%", height: "100%", objectFit: "cover" }} />}
            {u.url && u.media_type === "video" && <video src={u.url} controls style={{ width: "100%", height: "100%", objectFit: "cover" }} />}
          </div>
          <div style={{ flex: 1 }}>
            <span className={`pill ${u.status}`}>{u.status.replace("_", " ")}</span>
            <h3 style={{ marginTop: 8 }}>{u.title}</h3>
            <p className="muted" style={{ fontSize: ".85rem" }}>{u.category} · {u.location}</p>
            <p className="muted" style={{ fontSize: ".72rem" }}>Uploader: {u.user_id.slice(0, 8)}… · {new Date(u.created_at).toLocaleString()}</p>

            {u.mod ? (
              <div style={{ marginTop: 10, padding: "10px 12px", background: "var(--bg2, #f2efe4)", borderRadius: 2, fontSize: ".78rem" }}>
                <b style={{ fontFamily: "var(--mono)", textTransform: "uppercase", fontSize: ".68rem", color: "var(--sand)" }}>
                  AI Assessment — {u.mod.recommendation ?? "n/a"}
                  {u.mod.frames_sampled > 1 ? ` (${u.mod.frames_sampled} frames sampled)` : ""}
                </b>
                {u.mod.error ? (
                  <p className="muted" style={{ marginTop: 4 }}>Verification failed: {u.mod.error}</p>
                ) : (
                  <>
                    <p style={{ marginTop: 4 }}>
                      Relevance {u.mod.relevance_score}% · Quality {u.mod.quality_pass ? "pass" : "fail"}
                      {u.mod.safety_flags?.length ? ` · Flags: ${u.mod.safety_flags.join(", ")}` : ""}
                    </p>
                    {u.mod.duplicate_match_upload_id && (
                      <p style={{ marginTop: 4, color: "var(--bad)" }}>
                        Possible duplicate (distance {u.mod.duplicate_distance}) of upload {u.mod.duplicate_match_upload_id.slice(0, 8)}…
                      </p>
                    )}
                    <p className="muted" style={{ marginTop: 4, fontStyle: "italic" }}>{u.mod.reasoning}</p>
                  </>
                )}
              </div>
            ) : (
              <p className="muted" style={{ fontSize: ".72rem", marginTop: 8 }}>No AI assessment yet (video, or verification hasn&apos;t run).</p>
            )}

            <div style={{ marginTop: 12 }}>
              <RowActions id={u.id} />
            </div>
          </div>
        </div>
      ))}
    </main>
  );
}
