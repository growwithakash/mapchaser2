"use server";
import { createClient } from "@/lib/supabase/server";
import { assertAdmin } from "@/lib/auth/require-admin";
import { revalidatePath } from "next/cache";
import { notify } from "@/lib/notifications/send";

export async function approveUpload(id: string) {
  await assertAdmin();
  const supabase = await createClient();
  const { data: before } = await supabase.from("uploads").select("user_id, title").eq("id", id).single();
  const { data: after, error } = await supabase.from("uploads").update({ status: "approved" }).eq("id", id).select("points_awarded").single();
  if (error) throw new Error(error.message);
  if (before) await notify({ type: "upload_approved", userId: before.user_id, data: { title: before.title, points: after?.points_awarded ?? 0 } });
  revalidatePath("/admin/moderation");
}

export async function rejectUpload(id: string, reason: string) {
  await assertAdmin();
  const supabase = await createClient();
  const { data: before } = await supabase.from("uploads").select("user_id, title").eq("id", id).single();
  const { error } = await supabase.from("uploads").update({ status: "rejected", rejection_reason: reason }).eq("id", id);
  if (error) throw new Error(error.message);
  if (before) await notify({ type: "upload_rejected", userId: before.user_id, data: { title: before.title, reason } });
  revalidatePath("/admin/moderation");
}

export async function manualReview(id: string) {
  await assertAdmin();
  const supabase = await createClient();
  const { error } = await supabase.from("uploads").update({ status: "manual_review" }).eq("id", id);
  if (error) throw new Error(error.message);
  revalidatePath("/admin/moderation");
}
