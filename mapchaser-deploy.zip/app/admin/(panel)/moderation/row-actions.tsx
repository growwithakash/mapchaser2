"use client";
import { useState, useTransition } from "react";
import { approveUpload, rejectUpload } from "./actions";

const REASONS = [
  ["not_original", "Not original"],
  ["low_quality", "Low quality"],
  ["not_travel_nature", "Not travel/nature"],
  ["unsafe_content", "Unsafe content"],
  ["policy_violation", "Policy violation (strike)"],
  ["other", "Other"],
];

export default function RowActions({ id }: { id: string }) {
  const [pending, start] = useTransition();
  const [reason, setReason] = useState("not_original");
  const [rejecting, setRejecting] = useState(false);

  if (rejecting) {
    return (
      <div className="row" style={{ gap: 6 }}>
        <select value={reason} onChange={(e) => setReason(e.target.value)} style={{ width: "auto", padding: "6px 8px", fontSize: ".78rem" }}>
          {REASONS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </select>
        <button className="btn o" disabled={pending} onClick={() => start(() => rejectUpload(id, reason))} style={{ padding: "6px 12px", fontSize: ".72rem" }}>
          Confirm Reject
        </button>
        <button className="btn o" onClick={() => setRejecting(false)} style={{ padding: "6px 12px", fontSize: ".72rem" }}>Cancel</button>
      </div>
    );
  }

  return (
    <div className="row" style={{ gap: 6 }}>
      <button className="btn p" disabled={pending} onClick={() => start(() => approveUpload(id))} style={{ padding: "6px 14px", fontSize: ".72rem" }}>
        Approve
      </button>
      <button className="btn o" disabled={pending} onClick={() => setRejecting(true)} style={{ padding: "6px 14px", fontSize: ".72rem", borderColor: "var(--bad)", color: "var(--bad)" }}>
        Reject
      </button>
    </div>
  );
}
