"use client";
import { useState, useTransition } from "react";
import { adjustPoints } from "../actions";

export default function AdjustPointsForm({ userId }: { userId: string }) {
  const [points, setPoints] = useState(0);
  const [reason, setReason] = useState("");
  const [pending, start] = useTransition();
  const [msg, setMsg] = useState<string | null>(null);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    start(async () => {
      try {
        await adjustPoints(userId, points, reason);
        setMsg("Applied.");
        setPoints(0); setReason("");
      } catch (err: any) {
        setMsg(err.message);
      }
    });
  }

  return (
    <form onSubmit={submit}>
      <label htmlFor="pts">Points (Positive Or Negative)</label>
      <input id="pts" type="number" value={points} onChange={(e) => setPoints(Number(e.target.value))} />
      <label htmlFor="reason">Reason (Required, Logged To Audit)</label>
      <input id="reason" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="e.g. Campaign bonus, goodwill correction" />
      <button className="btn p" type="submit" disabled={pending || !points || !reason.trim()} style={{ marginTop: 12 }}>
        {pending ? "Applying…" : "Apply Adjustment"}
      </button>
      {msg && <p className="muted" style={{ marginTop: 8, fontSize: ".82rem" }}>{msg}</p>}
    </form>
  );
}
