"use client";
import { useTransition } from "react";
import { setUserFlag } from "../actions";

export default function FlagToggles({
  userId, verified, restricted, suspended,
}: { userId: string; verified: boolean; restricted: boolean; suspended: boolean }) {
  const [pending, start] = useTransition();

  const Toggle = ({ field, value, onLabel, offLabel }: any) => (
    <button
      className="btn o"
      disabled={pending}
      onClick={() => start(() => setUserFlag(userId, field, !value))}
      style={{ padding: "7px 14px", fontSize: ".74rem", borderColor: value ? "var(--good)" : "var(--line)" }}
    >
      {value ? onLabel : offLabel}
    </button>
  );

  return (
    <div className="row" style={{ gap: 8 }}>
      <Toggle field="verified" value={verified} onLabel="✓ Verified (click to unverify)" offLabel="Mark Verified" />
      <Toggle field="restricted" value={restricted} onLabel="Restricted (click to lift)" offLabel="Restrict Account" />
      <Toggle field="suspended" value={suspended} onLabel="Suspended (click to lift)" offLabel="Suspend Account" />
    </div>
  );
}
