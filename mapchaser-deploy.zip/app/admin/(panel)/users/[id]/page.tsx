import { createClient } from "@/lib/supabase/server";
import { requireAdmin } from "@/lib/auth/require-admin";
import { createAdminClient } from "@/lib/supabase/admin";
import { notFound } from "next/navigation";
import FlagToggles from "./flag-toggles";
import AdjustPointsForm from "./adjust-points-form";

export default async function UserDetail({ params }: { params: Promise<{ id: string }> }) {
  await requireAdmin();
  const { id } = await params;
  const supabase = await createClient();

  const [{ data: profile }, { data: wallet }, { data: uploads }, { data: transactions }, { data: pointAdjustments }, { data: reportsFiled }, { data: reportsAgainst }] =
    await Promise.all([
      supabase.from("profiles").select("*").eq("id", id).single(),
      supabase.from("wallets").select("*").eq("user_id", id).single(),
      supabase.from("uploads").select("*").eq("user_id", id).order("created_at", { ascending: false }),
      supabase.from("transactions").select("*").eq("user_id", id).order("created_at", { ascending: false }).limit(20),
      supabase.from("point_adjustments").select("*").eq("user_id", id).order("created_at", { ascending: false }),
      supabase.from("reports").select("*, uploads(title)").eq("reporter_id", id).order("created_at", { ascending: false }),
      supabase.from("reports").select("*, uploads!inner(title, user_id)").eq("uploads.user_id", id).order("created_at", { ascending: false }),
    ]);

  if (!profile) notFound();

  let email = id;
  try {
    const admin = createAdminClient();
    const { data } = await admin.auth.admin.getUserById(id);
    email = data.user?.email ?? id;
  } catch {}

  return (
    <main className="wrap" style={{ maxWidth: 800 }}>
      <a href="/admin/users" className="muted" style={{ fontSize: ".82rem", textDecoration: "underline" }}>← All users</a>
      <h1 style={{ marginTop: 8 }}>{profile.full_name || "Unnamed"}</h1>
      <p className="muted">{email} · joined {new Date(profile.created_at).toLocaleDateString()}</p>

      <div className="card">
        <h2>Status</h2>
        <FlagToggles userId={id} verified={profile.verified} restricted={profile.restricted} suspended={profile.suspended} />
        {profile.strikes > 0 && <p className="muted" style={{ marginTop: 10 }}>{profile.strikes} policy strike(s) on record.</p>}
      </div>

      <div className="stats">
        <div className="stat"><span>Available</span><b>{wallet?.available_points ?? 0}</b></div>
        <div className="stat"><span>Pending</span><b>{wallet?.pending_points ?? 0}</b></div>
        <div className="stat"><span>Locked</span><b>{wallet?.locked_points ?? 0}</b></div>
        <div className="stat"><span>Lifetime</span><b>{wallet?.lifetime_earned ?? 0}</b></div>
      </div>

      <div className="card">
        <h2>Manual Point Adjustment</h2>
        <p className="muted" style={{ fontSize: ".85rem" }}>Requires a reason. Immutable once applied — creates an audit record.</p>
        <AdjustPointsForm userId={id} />
        {!!pointAdjustments?.length && (
          <table style={{ marginTop: 16 }}>
            <thead><tr><th>Date</th><th>Points</th><th>Reason</th></tr></thead>
            <tbody>
              {pointAdjustments.map((a) => (
                <tr key={a.id}><td>{new Date(a.created_at).toLocaleDateString()}</td><td>{a.points > 0 ? "+" : ""}{a.points}</td><td>{a.reason}</td></tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="card">
        <h2>Uploads</h2>
        {!uploads?.length && <p className="muted">None yet.</p>}
        {!!uploads?.length && (
          <table>
            <thead><tr><th>Title</th><th>Category</th><th>Status</th></tr></thead>
            <tbody>
              {uploads.map((u) => (
                <tr key={u.id}><td>{u.title}</td><td>{u.category}</td><td><span className={`pill ${u.status}`}>{u.status.replace("_", " ")}</span></td></tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="card">
        <h2>Transaction History</h2>
        {!transactions?.length && <p className="muted">None yet.</p>}
        {!!transactions?.length && (
          <table>
            <thead><tr><th>Date</th><th>Type</th><th>Points</th><th>Note</th></tr></thead>
            <tbody>
              {transactions.map((t) => (
                <tr key={t.id}><td>{new Date(t.created_at).toLocaleDateString()}</td><td>{t.type}</td><td>{t.points}</td><td className="muted" style={{ fontSize: ".82rem" }}>{t.note}</td></tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {(!!reportsFiled?.length || !!reportsAgainst?.length) && (
        <div className="card">
          <h2>Reports</h2>
          {!!reportsAgainst?.length && (
            <>
              <h3 style={{ fontSize: ".9rem" }}>Against Their Content</h3>
              <ul className="muted" style={{ fontSize: ".85rem" }}>
                {reportsAgainst.map((r: any) => <li key={r.id}>{r.reason.replace("_", " ")} — &quot;{r.uploads?.title}&quot; ({r.status})</li>)}
              </ul>
            </>
          )}
          {!!reportsFiled?.length && (
            <>
              <h3 style={{ fontSize: ".9rem", marginTop: 12 }}>Filed By This User</h3>
              <ul className="muted" style={{ fontSize: ".85rem" }}>
                {reportsFiled.map((r: any) => <li key={r.id}>{r.reason.replace("_", " ")} — &quot;{r.uploads?.title}&quot; ({r.status})</li>)}
              </ul>
            </>
          )}
        </div>
      )}
    </main>
  );
}
