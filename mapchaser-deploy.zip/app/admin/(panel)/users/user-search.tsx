"use client";
import { useState } from "react";
import Link from "next/link";

type Row = {
  id: string; email: string; full_name: string | null; role: string;
  verified: boolean; restricted: boolean; suspended: boolean; strikes: number;
  available_points: number; lifetime_earned: number;
  approved: number; pending: number; rejected: number;
};

export default function UserSearch({ rows }: { rows: Row[] }) {
  const [q, setQ] = useState("");
  const term = q.trim().toLowerCase();
  const filtered = term
    ? rows.filter((r) => r.email?.toLowerCase().includes(term) || r.full_name?.toLowerCase().includes(term))
    : rows;

  return (
    <div className="card">
      <input placeholder="Search by email or name…" value={q} onChange={(e) => setQ(e.target.value)} />
      <p className="muted" style={{ fontSize: ".78rem", marginTop: 8 }}>{filtered.length} of {rows.length} users</p>

      <table style={{ marginTop: 10 }}>
        <thead>
          <tr><th>User</th><th>Flags</th><th>Points</th><th>Uploads</th><th></th></tr>
        </thead>
        <tbody>
          {filtered.map((r) => (
            <tr key={r.id}>
              <td>
                <span style={{ fontWeight: 600 }}>{r.full_name || "—"}</span>
                <br /><span className="muted" style={{ fontSize: ".78rem" }}>{r.email}</span>
              </td>
              <td>
                {r.role === "admin" && <span className="pill approved" style={{ marginRight: 4 }}>admin</span>}
                {r.verified && <span className="pill approved" style={{ marginRight: 4 }}>verified</span>}
                {r.restricted && <span className="pill pending" style={{ marginRight: 4 }}>restricted</span>}
                {r.suspended && <span className="pill rejected" style={{ marginRight: 4 }}>suspended</span>}
                {r.strikes > 0 && <span className="muted" style={{ fontSize: ".72rem" }}>{r.strikes} strike{r.strikes > 1 ? "s" : ""}</span>}
              </td>
              <td>{r.available_points} <span className="muted" style={{ fontSize: ".72rem" }}>({r.lifetime_earned} lifetime)</span></td>
              <td className="muted" style={{ fontSize: ".78rem" }}>{r.approved}✓ {r.pending}… {r.rejected}✕</td>
              <td><Link className="btn o" href={`/admin/users/${r.id}`} style={{ padding: "5px 12px", fontSize: ".72rem" }}>View</Link></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
