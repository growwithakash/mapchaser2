"use client";
import { useTransition } from "react";
import { resolveReport } from "./actions";

export default function ReportActions({ id }: { id: string }) {
  const [pending, start] = useTransition();
  return (
    <div className="row" style={{ gap: 6 }}>
      <button className="btn o" disabled={pending} onClick={() => start(() => resolveReport(id, "resolved"))} style={{ padding: "5px 12px", fontSize: ".7rem" }}>
        Resolve
      </button>
      <button className="btn o" disabled={pending} onClick={() => start(() => resolveReport(id, "dismissed"))} style={{ padding: "5px 12px", fontSize: ".7rem" }}>
        Dismiss
      </button>
    </div>
  );
}
