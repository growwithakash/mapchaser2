"use server";
import { createClient } from "@/lib/supabase/server";
import { assertAdmin } from "@/lib/auth/require-admin";
import { revalidatePath } from "next/cache";
import { notify } from "@/lib/notifications/send";

export async function setUserFlag(userId: string, field: "verified" | "restricted" | "suspended", value: boolean) {
  await assertAdmin();
  const supabase = await createClient();
  const { error } = await supabase.from("profiles").update({ [field]: value }).eq("id", userId);
  if (error) throw new Error(error.message);

  if (field === "suspended" && value) {
    await notify({ type: "account_suspended", userId, data: {} });
  }

  revalidatePath("/admin/users");
  revalidatePath(`/admin/users/${userId}`);
}

export async function adjustPoints(userId: string, points: number, reason: string) {
  await assertAdmin();
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("Not signed in.");
  if (!reason.trim()) throw new Error("A reason is required for any manual adjustment.");

  const { error } = await supabase.from("point_adjustments").insert({
    user_id: userId,
    points,
    reason,
    adjusted_by: user.id,
  });
  if (error) throw new Error(error.message);
  revalidatePath(`/admin/users/${userId}`);
}

export async function resolveReport(reportId: string, status: "resolved" | "dismissed") {
  await assertAdmin();
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const { error } = await supabase.from("reports")
    .update({ status, resolved_at: new Date().toISOString(), resolved_by: user?.id })
    .eq("id", reportId);
  if (error) throw new Error(error.message);
  revalidatePath("/admin/users");
}
