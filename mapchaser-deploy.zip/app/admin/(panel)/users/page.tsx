import { createClient } from "@/lib/supabase/server";
import { requireAdmin } from "@/lib/auth/require-admin";
import { createAdminClient } from "@/lib/supabase/admin";
import UserSearch from "./user-search";
import ReportActions from "./report-actions";

export default async function UsersPage() {
  await requireAdmin();
  const supabase = await createClient();

  const [{ data: profiles }, { data: wallets }, { data: uploads }, { data: openReports }] = await Promise.all([
    supabase.from("profiles").select("id, full_name, role, verified, restricted, suspended, strikes"),
    supabase.from("wallets").select("user_id, available_points, lifetime_earned"),
    supabase.from("uploads").select("user_id, status"),
    supabase.from("reports").select("*, uploads(title, user_id)").eq("status", "open").order("created_at", { ascending: true }),
  ]);

  let emails = new Map<string, string>();
  try {
    const admin = createAdminClient();
    const { data } = await admin.auth.admin.listUsers({ perPage: 1000 });
    (data?.users ?? []).forEach((u) => emails.set(u.id, u.email ?? "—"));
  } catch {
    // Service role not configured — fall back to showing IDs only.
  }

  const walletMap = new Map((wallets ?? []).map((w) => [w.user_id, w]));
  const uploadCounts = new Map<string, { approved: number; pending: number; rejected: number }>();
  (uploads ?? []).forEach((u) => {
    const c = uploadCounts.get(u.user_id) ?? { approved: 0, pending: 0, rejected: 0 };
    if (u.status === "approved") c.approved++;
    else if (u.status === "rejected") c.rejected++;
    else c.pending++;
    uploadCounts.set(u.user_id, c);
  });

  const rows = (profiles ?? []).map((p) => ({
    id: p.id,
    email: emails.get(p.id) ?? p.id.slice(0, 8) + "…",
    full_name: p.full_name,
    role: p.role,
    verified: p.verified,
    restricted: p.restricted,
    suspended: p.suspended,
    strikes: p.strikes,
    available_points: walletMap.get(p.id)?.available_points ?? 0,
    lifetime_earned: walletMap.get(p.id)?.lifetime_earned ?? 0,
    approved: uploadCounts.get(p.id)?.approved ?? 0,
    pending: uploadCounts.get(p.id)?.pending ?? 0,
    rejected: uploadCounts.get(p.id)?.rejected ?? 0,
  }));

  return (
    <main className="wrap" style={{ maxWidth: 900 }}>
      <h1>User Management</h1>
      <p className="muted">{rows.length} total users.</p>

      {!!openReports?.length && (
        <div className="card" style={{ borderColor: "var(--bad)" }}>
          <h2>Open Reports ({openReports.length})</h2>
          <table>
            <thead><tr><th>Reason</th><th>Content</th><th>Filed</th><th></th></tr></thead>
            <tbody>
              {openReports.map((r: any) => (
                <tr key={r.id}>
                  <td>{r.reason.replace("_", " ")}{r.details ? <><br /><span className="muted" style={{ fontSize: ".78rem" }}>{r.details}</span></> : null}</td>
                  <td>{r.uploads?.title ?? "—"}</td>
                  <td className="muted" style={{ fontSize: ".78rem" }}>{new Date(r.created_at).toLocaleDateString()}</td>
                  <td><ReportActions id={r.id} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <UserSearch rows={rows} />
    </main>
  );
}
