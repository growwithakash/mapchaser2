"use server";
import { createClient } from "@/lib/supabase/server";
import { assertAdmin } from "@/lib/auth/require-admin";
import { revalidatePath } from "next/cache";

export async function createCampaign(formData: FormData) {
  await assertAdmin();
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  const categories = String(formData.get("categories") || "")
    .split(",").map((s) => s.trim()).filter(Boolean);

  const { error } = await supabase.from("campaigns").insert({
    brand_name: String(formData.get("brand_name")),
    destination: String(formData.get("destination") || "") || null,
    budget: Number(formData.get("budget") || 0) || null,
    reward_pool_points: Number(formData.get("reward_pool_points") || 0),
    start_date: String(formData.get("start_date")),
    end_date: String(formData.get("end_date")),
    content_rules: String(formData.get("content_rules") || "") || null,
    eligible_categories: categories.length ? categories : null,
    participant_limit: Number(formData.get("participant_limit") || 0) || null,
    created_by: user?.id,
  });
  if (error) throw new Error(error.message);
  revalidatePath("/admin/campaigns");
}

export async function setCampaignStatus(id: string, status: string) {
  await assertAdmin();
  const supabase = await createClient();
  const { error } = await supabase.from("campaigns").update({ status }).eq("id", id);
  if (error) throw new Error(error.message);
  revalidatePath("/admin/campaigns");
}
