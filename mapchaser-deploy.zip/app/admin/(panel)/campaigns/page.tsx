import { createClient } from "@/lib/supabase/server";
import { requireAdmin } from "@/lib/auth/require-admin";
import { createCampaign } from "./actions";
import StatusActions from "./status-actions";

export default async function CampaignsPage() {
  await requireAdmin();
  const supabase = await createClient();
  const { data: campaigns } = await supabase.from("campaigns").select("*").order("created_at", { ascending: false });

  return (
    <main className="wrap" style={{ maxWidth: 900 }}>
      <h1>Campaigns</h1>
      <p className="muted">Brand-sponsored reward pools. Budget and points are never touched by client code.</p>

      <form action={createCampaign} className="card">
        <h2>New Campaign</h2>
        <label htmlFor="brand_name">Brand Name</label>
        <input id="brand_name" name="brand_name" required />
        <label htmlFor="destination">Destination</label>
        <input id="destination" name="destination" placeholder="e.g. Himachal Pradesh" />
        <div className="row">
          <div style={{ flex: 1 }}>
            <label htmlFor="budget">Budget (₹)</label>
            <input id="budget" name="budget" type="number" step="0.01" />
          </div>
          <div style={{ flex: 1 }}>
            <label htmlFor="reward_pool_points">Reward Pool (Points)</label>
            <input id="reward_pool_points" name="reward_pool_points" type="number" required />
          </div>
        </div>
        <div className="row">
          <div style={{ flex: 1 }}>
            <label htmlFor="start_date">Start Date</label>
            <input id="start_date" name="start_date" type="date" required />
          </div>
          <div style={{ flex: 1 }}>
            <label htmlFor="end_date">End Date</label>
            <input id="end_date" name="end_date" type="date" required />
          </div>
        </div>
        <label htmlFor="categories">Eligible Categories (Comma-Separated)</label>
        <input id="categories" name="categories" placeholder="Mountains, Adventure" />
        <label htmlFor="participant_limit">Participant Limit</label>
        <input id="participant_limit" name="participant_limit" type="number" />
        <label htmlFor="content_rules">Content Rules</label>
        <textarea id="content_rules" name="content_rules" rows={3} />
        <button className="btn p" type="submit" style={{ marginTop: 14 }}>Create Campaign</button>
      </form>

      {(campaigns ?? []).map((c) => (
        <div key={c.id} className="card">
          <div className="row" style={{ justifyContent: "space-between" }}>
            <div>
              <span className={`pill ${c.status === "active" ? "approved" : c.status === "cancelled" ? "rejected" : "pending"}`}>{c.status}</span>
              <h3 style={{ marginTop: 8 }}>{c.brand_name} {c.destination ? `— ${c.destination}` : ""}</h3>
              <p className="muted" style={{ fontSize: ".85rem" }}>
                {c.start_date} → {c.end_date} · Pool: {c.reward_pool_points} pts ({c.points_awarded} awarded)
                {c.budget ? ` · Budget ₹${c.budget}` : ""}
              </p>
              {c.eligible_categories && <p className="muted" style={{ fontSize: ".78rem" }}>Categories: {c.eligible_categories.join(", ")}</p>}
            </div>
            <StatusActions id={c.id} status={c.status} />
          </div>
        </div>
      ))}
    </main>
  );
}
