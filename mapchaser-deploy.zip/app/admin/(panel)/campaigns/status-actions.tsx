"use client";
import { useTransition } from "react";
import { setCampaignStatus } from "./actions";

const NEXT: Record<string, { label: string; to: string }[]> = {
  draft: [{ label: "Activate", to: "active" }, { label: "Cancel", to: "cancelled" }],
  active: [{ label: "Pause", to: "paused" }, { label: "Complete", to: "completed" }, { label: "Cancel", to: "cancelled" }],
  paused: [{ label: "Resume", to: "active" }, { label: "Cancel", to: "cancelled" }],
  completed: [],
  cancelled: [],
};

export default function StatusActions({ id, status }: { id: string; status: string }) {
  const [pending, start] = useTransition();
  const options = NEXT[status] ?? [];
  if (!options.length) return null;
  return (
    <div className="row" style={{ gap: 6 }}>
      {options.map((o) => (
        <button key={o.to} className="btn o" disabled={pending} onClick={() => start(() => setCampaignStatus(id, o.to))} style={{ padding: "5px 12px", fontSize: ".7rem" }}>
          {o.label}
        </button>
      ))}
    </div>
  );
}
