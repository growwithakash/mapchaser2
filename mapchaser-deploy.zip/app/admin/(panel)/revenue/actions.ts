"use server";
import { createClient } from "@/lib/supabase/server";
import { assertAdmin } from "@/lib/auth/require-admin";
import { revalidatePath } from "next/cache";
import { notify } from "@/lib/notifications/send";

export async function addRevenue(formData: FormData) {
  await assertAdmin();
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const { error } = await supabase.from("revenue_records").insert({
    source: String(formData.get("source")),
    description: String(formData.get("description") || "") || null,
    gross_amount: Number(formData.get("gross_amount") || 0),
    platform_fee: Number(formData.get("platform_fee") || 0),
    reward_allocation: Number(formData.get("reward_allocation") || 0),
    status: String(formData.get("status") || "pending"),
    recorded_by: user?.id,
  });
  if (error) throw new Error(error.message);
  revalidatePath("/admin/revenue");
}

export async function setWithdrawalStatus(id: string, status: string) {
  await assertAdmin();
  const supabase = await createClient();
  const { data: w } = await supabase.from("withdrawals").select("user_id, points, final_amount").eq("id", id).single();
  const { error } = await supabase.from("withdrawals").update({ status }).eq("id", id);
  if (error) throw new Error(error.message);

  if (w) {
    const amount = Number(w.final_amount).toFixed(2);
    if (status === "processing") await notify({ type: "withdrawal_processing", userId: w.user_id, data: { points: w.points, amount } });
    else if (status === "completed") await notify({ type: "withdrawal_completed", userId: w.user_id, data: { points: w.points, amount } });
    else if (status === "rejected") await notify({ type: "withdrawal_rejected", userId: w.user_id, data: { points: w.points } });
    else if (status === "cancelled") await notify({ type: "withdrawal_cancelled", userId: w.user_id, data: { points: w.points } });
  }
  revalidatePath("/admin/revenue");
}
