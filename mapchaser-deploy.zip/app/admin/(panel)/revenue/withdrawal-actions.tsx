"use client";
import { useTransition } from "react";
import { setWithdrawalStatus } from "./actions";

export default function WithdrawalActions({ id, status }: { id: string; status: string }) {
  const [pending, start] = useTransition();
  if (status === "completed") return <span className="muted" style={{ fontSize: ".72rem" }}>Final</span>;
  const options: { label: string; to: string }[] =
    status === "pending" ? [{ label: "Start Processing", to: "processing" }, { label: "Reject", to: "rejected" }]
    : status === "processing" ? [{ label: "Mark Completed", to: "completed" }, { label: "Cancel", to: "cancelled" }]
    : [];
  if (!options.length) return null;
  return (
    <div className="row" style={{ gap: 6 }}>
      {options.map((o) => (
        <button key={o.to} className="btn o" disabled={pending} onClick={() => start(() => setWithdrawalStatus(id, o.to))} style={{ padding: "5px 12px", fontSize: ".7rem" }}>
          {o.label}
        </button>
      ))}
    </div>
  );
}
