import { createClient } from "@/lib/supabase/server";
import { requireAdmin } from "@/lib/auth/require-admin";
import { addRevenue } from "./actions";
import WithdrawalActions from "./withdrawal-actions";

export default async function RevenuePage() {
  await requireAdmin();
  const supabase = await createClient();
  const [{ data: revenue }, { data: withdrawals }] = await Promise.all([
    supabase.from("revenue_records").select("*").order("created_at", { ascending: false }),
    supabase.from("withdrawals").select("*").order("requested_at", { ascending: false }),
  ]);

  const netTotal = (revenue ?? []).reduce((s, r) => s + Number(r.net_amount ?? 0), 0);

  return (
    <main className="wrap" style={{ maxWidth: 900 }}>
      <h1>Revenue &amp; Withdrawals</h1>

      <div className="stats">
        <div className="stat"><span>Net Revenue</span><b>₹{netTotal.toFixed(2)}</b></div>
        <div className="stat"><span>Records</span><b>{revenue?.length ?? 0}</b></div>
        <div className="stat"><span>Withdrawals</span><b>{withdrawals?.length ?? 0}</b></div>
        <div className="stat"><span>Pending</span><b>{withdrawals?.filter((w) => w.status === "pending").length ?? 0}</b></div>
      </div>

      <form action={addRevenue} className="card">
        <h2>Record Revenue</h2>
        <label htmlFor="source">Source</label>
        <select id="source" name="source" required>
          <option value="sponsorship">Sponsorship</option>
          <option value="affiliate">Affiliate</option>
          <option value="premium">Premium</option>
          <option value="b2b">B2B</option>
          <option value="licensing">Licensing</option>
          <option value="advertising">Advertising</option>
        </select>
        <label htmlFor="description">Description</label>
        <input id="description" name="description" />
        <div className="row">
          <div style={{ flex: 1 }}><label htmlFor="gross_amount">Gross (₹)</label><input id="gross_amount" name="gross_amount" type="number" step="0.01" required /></div>
          <div style={{ flex: 1 }}><label htmlFor="platform_fee">Platform Fee (₹)</label><input id="platform_fee" name="platform_fee" type="number" step="0.01" /></div>
          <div style={{ flex: 1 }}><label htmlFor="reward_allocation">Reward Allocation (₹)</label><input id="reward_allocation" name="reward_allocation" type="number" step="0.01" /></div>
        </div>
        <label htmlFor="status">Status</label>
        <select id="status" name="status">
          <option value="pending">Pending</option>
          <option value="confirmed">Confirmed</option>
        </select>
        <button className="btn p" type="submit" style={{ marginTop: 14 }}>Add Record</button>
      </form>

      <div className="card">
        <h2>Revenue Records</h2>
        <table>
          <thead><tr><th>Source</th><th>Gross</th><th>Fee</th><th>Net</th><th>Status</th></tr></thead>
          <tbody>
            {(revenue ?? []).map((r) => (
              <tr key={r.id}>
                <td>{r.source}</td>
                <td>₹{Number(r.gross_amount).toFixed(2)}</td>
                <td>₹{Number(r.platform_fee).toFixed(2)}</td>
                <td>₹{Number(r.net_amount).toFixed(2)}</td>
                <td><span className="pill pending">{r.status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card">
        <h2>Withdrawal Requests</h2>
        <table>
          <thead><tr><th>User</th><th>Points</th><th>Method</th><th>Amount</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {(withdrawals ?? []).map((w) => (
              <tr key={w.id}>
                <td>{w.user_id.slice(0, 8)}…</td>
                <td>{w.points}</td>
                <td>{w.payment_method.replace("_", " ")}</td>
                <td>₹{Number(w.final_amount).toFixed(2)}</td>
                <td><span className={`pill ${w.status === "completed" ? "approved" : ["rejected","cancelled"].includes(w.status) ? "rejected" : "pending"}`}>{w.status}</span></td>
                <td><WithdrawalActions id={w.id} status={w.status} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </main>
  );
}
