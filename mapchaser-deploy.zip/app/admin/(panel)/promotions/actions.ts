"use server";
import { createClient } from "@/lib/supabase/server";
import { assertAdmin } from "@/lib/auth/require-admin";
import { revalidatePath } from "next/cache";

export async function createPromotion(formData: FormData) {
  await assertAdmin();
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  const endsAtRaw = String(formData.get("ends_at") || "");
  const campaignId = String(formData.get("campaign_id") || "");

  const { error } = await supabase.from("promotions").insert({
    type: String(formData.get("type")),
    title: String(formData.get("title")),
    link_url: String(formData.get("link_url")),
    destination: String(formData.get("destination") || "") || null,
    campaign_id: campaignId || null,
    ends_at: endsAtRaw ? new Date(endsAtRaw).toISOString() : null,
    created_by: user?.id,
  });
  if (error) throw new Error(error.message);
  revalidatePath("/admin/promotions");
  revalidatePath("/explore");
}

export async function togglePromotionActive(id: string, active: boolean) {
  await assertAdmin();
  const supabase = await createClient();
  const { error } = await supabase.from("promotions").update({ active }).eq("id", id);
  if (error) throw new Error(error.message);
  revalidatePath("/admin/promotions");
  revalidatePath("/explore");
}
