import { createClient } from "@/lib/supabase/server";
import { requireAdmin } from "@/lib/auth/require-admin";
import { createPromotion } from "./actions";
import ToggleButton from "./toggle-button";

export default async function PromotionsPage() {
  await requireAdmin();
  const supabase = await createClient();
  const [{ data: promotions }, { data: campaigns }] = await Promise.all([
    supabase.from("promotions").select("*, campaigns(brand_name)").order("created_at", { ascending: false }),
    supabase.from("campaigns").select("id, brand_name").order("created_at", { ascending: false }),
  ]);

  return (
    <main className="wrap" style={{ maxWidth: 900 }}>
      <h1>Promotions</h1>
      <p className="muted">
        Sponsored, promoted and affiliate placements. Always labelled as such on the public site —
        never blended in with organic uploads.
      </p>

      <form action={createPromotion} className="card">
        <h2>New Promotion</h2>
        <label htmlFor="type">Type</label>
        <select id="type" name="type" required>
          <option value="sponsored">Sponsored</option>
          <option value="promoted">Promoted</option>
          <option value="affiliate">Affiliate</option>
        </select>
        <label htmlFor="title">Title</label>
        <input id="title" name="title" placeholder="e.g. Discover Himachal with XYZ Tourism" required />
        <label htmlFor="link_url">Link URL</label>
        <input id="link_url" name="link_url" type="url" placeholder="https://…" required />
        <label htmlFor="destination">Destination (Optional)</label>
        <input id="destination" name="destination" placeholder="e.g. Himachal Pradesh" />
        <label htmlFor="campaign_id">Linked Campaign (Optional)</label>
        <select id="campaign_id" name="campaign_id">
          <option value="">None</option>
          {(campaigns ?? []).map((c) => <option key={c.id} value={c.id}>{c.brand_name}</option>)}
        </select>
        <label htmlFor="ends_at">Ends (Optional)</label>
        <input id="ends_at" name="ends_at" type="date" />
        <button className="btn p" type="submit" style={{ marginTop: 14 }}>Create</button>
      </form>

      {(promotions ?? []).map((p: any) => (
        <div key={p.id} className="card">
          <div className="row" style={{ justifyContent: "space-between" }}>
            <div>
              <span className="pill pending" style={{ textTransform: "uppercase" }}>{p.type}</span>
              <h3 style={{ marginTop: 8 }}>{p.title}</h3>
              <p className="muted" style={{ fontSize: ".85rem" }}>
                {p.destination ? `${p.destination} · ` : ""}{p.link_url}
                {p.campaigns?.brand_name ? ` · Campaign: ${p.campaigns.brand_name}` : ""}
              </p>
              <p className="muted" style={{ fontSize: ".78rem" }}>
                {p.ends_at ? `Ends ${new Date(p.ends_at).toLocaleDateString()}` : "No end date"}
              </p>
            </div>
            <ToggleButton id={p.id} active={p.active} />
          </div>
        </div>
      ))}
    </main>
  );
}
