"use client";
import { useTransition } from "react";
import { togglePromotionActive } from "./actions";

export default function ToggleButton({ id, active }: { id: string; active: boolean }) {
  const [pending, start] = useTransition();
  return (
    <button
      className="btn o"
      disabled={pending}
      onClick={() => start(() => togglePromotionActive(id, !active))}
      style={{ padding: "5px 12px", fontSize: ".72rem", borderColor: active ? "var(--good)" : "var(--line)" }}
    >
      {active ? "Active (click to pause)" : "Paused (click to activate)"}
    </button>
  );
}
