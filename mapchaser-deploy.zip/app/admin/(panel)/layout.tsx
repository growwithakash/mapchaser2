import { requireAdmin } from "@/lib/auth/require-admin";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  await requireAdmin();

  return (
    <div>
      <div style={{ background: "var(--ink)", color: "var(--ivory)", padding: "10px 0" }}>
        <div className="wrap" style={{ padding: "0 20px", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 10 }}>
          <span className="brand" style={{ color: "var(--ivory)" }}>MAP CHASER — ADMIN</span>
          <nav className="row" style={{ fontFamily: "var(--mono)", fontSize: ".7rem", letterSpacing: ".04em", textTransform: "uppercase" }}>
            <a href="/admin" style={{ color: "var(--ivory)", opacity: .8 }}>Dashboard</a>
            <a href="/admin/users" style={{ color: "var(--ivory)", opacity: .8 }}>Users</a>
            <a href="/admin/moderation" style={{ color: "var(--ivory)", opacity: .8 }}>Moderation</a>
            <a href="/admin/campaigns" style={{ color: "var(--ivory)", opacity: .8 }}>Campaigns</a>
            <a href="/admin/promotions" style={{ color: "var(--ivory)", opacity: .8 }}>Promotions</a>
            <a href="/admin/revenue" style={{ color: "var(--ivory)", opacity: .8 }}>Revenue</a>
          </nav>
          <span style={{ fontFamily: "var(--mono)", fontSize: ".68rem", color: "var(--gold)" }}>AAL2 · VERIFIED</span>
        </div>
      </div>
      {children}
    </div>
  );
}
