import { createClient } from "@/lib/supabase/server";
import { requireAdmin } from "@/lib/auth/require-admin";

async function countBy(supabase: any, table: string, col: string, val: string) {
  const { count } = await supabase.from(table).select("*", { count: "exact", head: true }).eq(col, val);
  return count ?? 0;
}

export default async function AdminDashboard() {
  await requireAdmin();
  const supabase = await createClient();

  const [
    { count: totalUsers },
    pending,
    manualReview,
    approved,
    rejected,
    { data: wallets },
    { count: pendingWithdrawals },
    { data: pendingWithdrawalRows },
    { data: revenueRows },
    { data: activeCampaigns },
  ] = await Promise.all([
    supabase.from("profiles").select("*", { count: "exact", head: true }),
    countBy(supabase, "uploads", "status", "pending"),
    countBy(supabase, "uploads", "status", "manual_review"),
    countBy(supabase, "uploads", "status", "approved"),
    countBy(supabase, "uploads", "status", "rejected"),
    supabase.from("wallets").select("lifetime_earned, redeemed_points"),
    supabase.from("withdrawals").select("*", { count: "exact", head: true }).eq("status", "pending"),
    supabase.from("withdrawals").select("final_amount").in("status", ["pending", "processing"]),
    supabase.from("revenue_records").select("net_amount"),
    supabase.from("campaigns").select("reward_pool_points, points_awarded").eq("status", "active"),
  ]);

  const pointsIssued = (wallets ?? []).reduce((s: number, w: any) => s + (w.lifetime_earned ?? 0), 0);
  const pointsRedeemed = (wallets ?? []).reduce((s: number, w: any) => s + (w.redeemed_points ?? 0), 0);
  const withdrawalsOwed = (pendingWithdrawalRows ?? []).reduce((s: number, w: any) => s + Number(w.final_amount ?? 0), 0);
  const netRevenue = (revenueRows ?? []).reduce((s: number, r: any) => s + Number(r.net_amount ?? 0), 0);
  const rewardPool = (activeCampaigns ?? []).reduce((s: number, c: any) => s + (c.reward_pool_points - c.points_awarded), 0);

  return (
    <main className="wrap">
      <h1>Dashboard</h1>
      <p className="muted">Live figures, read directly from the database.</p>

      <div className="stats">
        <div className="stat"><span>Total Users</span><b>{totalUsers ?? 0}</b></div>
        <div className="stat"><span>Pending Review</span><b>{pending + manualReview}</b></div>
        <div className="stat"><span>Approved</span><b>{approved}</b></div>
        <div className="stat"><span>Rejected</span><b>{rejected}</b></div>
        <div className="stat"><span>Points Issued</span><b>{pointsIssued}</b></div>
        <div className="stat"><span>Points Redeemed</span><b>{pointsRedeemed}</b></div>
        <div className="stat"><span>Withdrawals Pending</span><b>{pendingWithdrawals ?? 0}</b></div>
        <div className="stat"><span>Owed (Pending)</span><b>₹{withdrawalsOwed.toFixed(2)}</b></div>
        <div className="stat"><span>Net Revenue</span><b>₹{netRevenue.toFixed(2)}</b></div>
        <div className="stat"><span>Active Reward Pool</span><b>{rewardPool} pts</b></div>
      </div>

      <div className="card">
        <h2>Jump To</h2>
        <div className="row">
          <a className="btn o" href="/admin/users">User Management</a>
          <a className="btn o" href="/admin/moderation">Content Moderation</a>
          <a className="btn o" href="/admin/campaigns">Campaigns</a>
          <a className="btn o" href="/admin/promotions">Promotions</a>
          <a className="btn o" href="/admin/revenue">Revenue &amp; Withdrawals</a>
        </div>
      </div>
    </main>
  );
}
