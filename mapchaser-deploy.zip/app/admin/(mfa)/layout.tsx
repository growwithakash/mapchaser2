import { notFound, redirect } from "next/navigation";
import { getAdminState } from "@/lib/auth/require-admin";

// The 2FA setup/verify pages must be reachable by an admin who has NOT yet passed 2FA,
// so they live outside the (panel) layout that demands it. They still require a
// signed-in admin account.
export default async function MfaLayout({ children }: { children: React.ReactNode }) {
  const { state } = await getAdminState();
  if (state === "anon") redirect("/login?next=/admin");
  if (state === "not_admin") notFound();
  if (state === "ok") redirect("/admin");
  return <>{children}</>;
}
