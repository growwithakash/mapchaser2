"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function MfaSetup() {
  const router = useRouter();
  const supabase = createClient();
  const [qr, setQr] = useState<string | null>(null);
  const [secret, setSecret] = useState("");
  const [factorId, setFactorId] = useState("");
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [started, setStarted] = useState(false);

  async function startEnroll() {
    setErr(null);
    setBusy(true);
    try {
      const { data: existing } = await supabase.auth.mfa.listFactors();
      for (const f of existing?.all ?? []) {
        if (f.factor_type === "totp" && f.status === "unverified") {
          await supabase.auth.mfa.unenroll({ factorId: f.id });
        }
      }
      const { data, error } = await supabase.auth.mfa.enroll({ factorType: "totp" });
      if (error) throw error;
      setQr(data.totp.qr_code);
      setSecret(data.totp.secret);
      setFactorId(data.id);
      setStarted(true);
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function verifyCode(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    setBusy(true);
    try {
      const { data: challenge, error: chErr } = await supabase.auth.mfa.challenge({ factorId });
      if (chErr) throw chErr;
      const { error: vErr } = await supabase.auth.mfa.verify({
        factorId,
        challengeId: challenge.id,
        code,
      });
      if (vErr) throw vErr;
      router.push("/admin");
      router.refresh();
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="wrap">
      <h1>Set Up Admin 2FA</h1>
      <p className="muted">
        Admin access requires two-factor authentication. Scan the QR code with an authenticator app
        (Google Authenticator, 1Password, Authy) and enter the 6-digit code to continue.
      </p>

      <div className="card">
        {!started && (
          <button className="btn p" onClick={startEnroll} disabled={busy}>
            {busy ? "Preparing…" : "Start Setup"}
          </button>
        )}

        {started && (
          <>
            {qr && (
              <div style={{ background: "#fff", padding: 12, display: "inline-block", border: "1px solid var(--line)" }}
                   dangerouslySetInnerHTML={{ __html: qr }} />
            )}
            <p className="muted" style={{ fontSize: ".82rem", marginTop: 10 }}>
              Can&apos;t scan? Enter this key manually: <code>{secret}</code>
            </p>

            <form onSubmit={verifyCode} style={{ marginTop: 16 }}>
              <label htmlFor="code">6-digit code</label>
              <input id="code" value={code} onChange={(e) => setCode(e.target.value)} inputMode="numeric" maxLength={6} />
              <button className="btn p" type="submit" disabled={busy || code.length < 6} style={{ marginTop: 14 }}>
                {busy ? "Verifying…" : "Verify & Enable 2FA"}
              </button>
            </form>
          </>
        )}

        {err && <p className="err" style={{ marginTop: 14 }}>{err}</p>}
      </div>
    </main>
  );
}
