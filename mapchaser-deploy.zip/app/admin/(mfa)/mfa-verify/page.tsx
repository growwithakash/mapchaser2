"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function MfaVerify() {
  const router = useRouter();
  const supabase = createClient();
  const [factorId, setFactorId] = useState("");
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    (async () => {
      const { data, error } = await supabase.auth.mfa.listFactors();
      if (error) { setErr(error.message); return; }
      const factor = data.totp.find((f) => f.status === "verified");
      if (factor) { setFactorId(factor.id); setReady(true); }
      else setErr("No verified authenticator found. Contact another admin to reset your 2FA.");
    })();
  }, []);

  async function handleVerify(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    setBusy(true);
    try {
      const { data: challenge, error: chErr } = await supabase.auth.mfa.challenge({ factorId });
      if (chErr) throw chErr;
      const { error: vErr } = await supabase.auth.mfa.verify({ factorId, challengeId: challenge.id, code });
      if (vErr) throw vErr;
      router.push("/admin");
      router.refresh();
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="wrap">
      <h1>Verify 2FA</h1>
      <p className="muted">Enter the 6-digit code from your authenticator app to continue to the admin dashboard.</p>
      <div className="card">
        {ready && (
          <form onSubmit={handleVerify}>
            <label htmlFor="code">6-digit code</label>
            <input id="code" value={code} onChange={(e) => setCode(e.target.value)} inputMode="numeric" maxLength={6} autoFocus />
            <button className="btn p" type="submit" disabled={busy || code.length < 6} style={{ marginTop: 14 }}>
              {busy ? "Verifying…" : "Verify"}
            </button>
          </form>
        )}
        {err && <p className="err" style={{ marginTop: 14 }}>{err}</p>}
      </div>
    </main>
  );
}
