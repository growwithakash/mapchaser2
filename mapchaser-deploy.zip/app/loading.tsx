export default function Loading() {
  return (
    <div className="state">
      <div className="mark">
        <svg viewBox="0 0 48 48">
          <circle className="ring" cx="24" cy="24" r="20" />
          <circle className="sweep" cx="24" cy="24" r="20" />
        </svg>
      </div>
      <span className="eyebrow">Map Chaser</span>
      <h1>Preparing your next destination…</h1>
    </div>
  );
}
