export default function Offline() {
  return (
    <div className="state">
      <div className="mark">
        <svg viewBox="0 0 48 48">
          <circle className="ring" cx="24" cy="24" r="20" />
        </svg>
      </div>
      <span className="eyebrow">Map Chaser</span>
      <h1>No signal out here.</h1>
      <p>You&apos;re offline. Reconnect to keep chasing — your wallet and uploads are waiting on the other side.</p>
      <a className="btn p" href="/">Try Again</a>
    </div>
  );
}
