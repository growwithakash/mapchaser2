export default function NotFound() {
  return (
    <div className="state">
      <div className="mark">
        <svg viewBox="0 0 48 48">
          <circle className="ring" cx="24" cy="24" r="20" />
        </svg>
      </div>
      <span className="eyebrow">Map Chaser</span>
      <h1>This trail doesn&apos;t exist.</h1>
      <p>The page you&apos;re chasing isn&apos;t here. Try another route.</p>
      <a className="btn p" href="/">Back Home</a>
    </div>
  );
}
