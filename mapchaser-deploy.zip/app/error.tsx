"use client";

export default function Error({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="state">
      <div className="mark">
        <svg viewBox="0 0 48 48">
          <circle className="ring" cx="24" cy="24" r="20" />
        </svg>
      </div>
      <span className="eyebrow">Map Chaser</span>
      <h1>Looks like this trail disappeared.</h1>
      <p>Something went wrong loading this page. Try again, or choose another path.</p>
      <div className="row" style={{ justifyContent: "center", marginTop: 20 }}>
        <button className="btn p" onClick={() => reset()}>Try Again</button>
        <a className="btn o" href="/">Back Home</a>
      </div>
    </div>
  );
}
