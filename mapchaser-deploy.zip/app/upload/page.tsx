"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import SiteNav from "@/components/site-nav";

const CATEGORIES = [
  "Mountains","Forest","Waterfall","Beach","Lake","Wildlife","Landscape",
  "Sunrise","Sunset","Adventure","Road Trip","Camping","City","Heritage","Travel","Nature",
];

const STEPS = ["Capture", "Process", "Review", "Approved", "Reward"];

function Pipeline({ stage }: { stage: number }) {
  return (
    <div style={{ display: "flex", alignItems: "center", margin: "28px 0 6px" }}>
      {STEPS.map((label, i) => {
        const reached = i <= stage;
        const active = i === stage;
        return (
          <div key={label} style={{ display: "flex", alignItems: "center", flex: i < STEPS.length - 1 ? 1 : "none" }}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 8, minWidth: 54 }}>
              <div
                style={{
                  width: 14, height: 14, borderRadius: "50%",
                  background: reached ? "var(--gold)" : "transparent",
                  border: `1.5px solid ${reached ? "var(--gold)" : "var(--line)"}`,
                  boxShadow: active ? "0 0 0 5px rgba(214,168,95,.22)" : "none",
                  transition: "box-shadow .3s",
                }}
              />
              <span style={{ fontFamily: "var(--mono)", fontSize: ".62rem", letterSpacing: ".04em", textTransform: "uppercase", color: reached ? "var(--ink)" : "var(--mute)", textAlign: "center" }}>
                {label}
              </span>
            </div>
            {i < STEPS.length - 1 && (
              <div style={{ flex: 1, height: 1, background: i < stage ? "var(--gold)" : "var(--line)", margin: "0 4px 18px" }} />
            )}
          </div>
        );
      })}
    </div>
  );
}

export default function UploadPage() {
  const router = useRouter();
  const supabase = createClient();
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState("");
  const [location, setLocation] = useState("");
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [own, setOwn] = useState(false);
  const [busy, setBusy] = useState(false);
  const [stage, setStage] = useState(0); // 0 nothing, 1 capture, 2 process, 3 review
  const [msg, setMsg] = useState<{ type: "err" | "ok"; text: string } | null>(null);

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const { data: profile } = await supabase.from("profiles").select("date_of_birth").eq("id", user.id).single();
      if (profile && !profile.date_of_birth) router.push("/complete-profile");
    })();
  }, []);

  function onFile(f: File | null) {
    setFile(f);
    setStage(f ? 1 : 0);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);

    if (!file || !title || !location || !category || !own) {
      setMsg({ type: "err", text: "Fill in every field, choose a file, and confirm ownership." });
      return;
    }
    const mediaType = file.type.startsWith("video/") ? "video" : "photo";
    if (!file.type.startsWith("image/") && !file.type.startsWith("video/")) {
      setMsg({ type: "err", text: "Only image or video files are accepted." });
      return;
    }

    setBusy(true);
    setStage(2);
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) {
        router.push("/login");
        return;
      }

      const path = `${user.id}/${Date.now()}-${file.name}`;
      const { error: upErr } = await supabase.storage.from("uploads").upload(path, file);
      if (upErr) throw upErr;

      const { data: inserted, error: dbErr } = await supabase
        .from("uploads")
        .insert({
          user_id: user.id,
          title,
          location,
          category,
          description,
          media_type: mediaType,
          file_path: path,
        })
        .select("id")
        .single();
      if (dbErr) throw dbErr;

      setStage(3);
      setMsg({ type: "ok", text: "Logged. Running verification…" });

      try {
        const res = await fetch("/api/moderate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ upload_id: inserted.id }),
        });
        const result = await res.json();

        if (result.status === "approved") {
          setStage(4);
          setMsg({ type: "ok", text: "Verified and approved — points have been added to your wallet." });
        } else if (result.status === "rejected") {
          setMsg({ type: "err", text: "Not approved for rewards — this didn't pass verification. Check your dashboard for details." });
        } else {
          setMsg({ type: "ok", text: "Logged. A reviewer will check this shortly — no points until then." });
        }
      } catch {
        setMsg({ type: "ok", text: "Logged. Your chase is now under review — verification runs before any reward is earned." });
      }
    } catch (err: any) {
      setStage(file ? 1 : 0);
      setMsg({ type: "err", text: err.message ?? "The chase was interrupted. Try again." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
    <SiteNav />
    <main className="wrap">
      <span style={{ fontFamily: "var(--mono)", fontSize: ".72rem", letterSpacing: ".1em", color: "var(--sand)", textTransform: "uppercase" }}>
        Expedition Log
      </span>
      <h1 style={{ marginTop: 10 }}>Start a New Chase</h1>
      <p className="muted">Every journey leaves a story. Capture yours — it's stored in real object storage, and points are added only after approval.</p>

      <Pipeline stage={stage} />

      <form className="card" onSubmit={handleSubmit}>
        <label htmlFor="file">Photo or Video</label>
        <input id="file" type="file" accept="image/*,video/*" onChange={(e) => onFile(e.target.files?.[0] ?? null)} />

        <label htmlFor="title">Title</label>
        <input id="title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Sunrise over the pass" />

        <label htmlFor="loc">Location</label>
        <input id="loc" value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Chopta, Uttarakhand" />

        <label htmlFor="cat">Category</label>
        <select id="cat" value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="">Choose a category</option>
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>

        <label htmlFor="desc">Description (Optional)</label>
        <textarea id="desc" rows={3} value={description} onChange={(e) => setDescription(e.target.value)} />

        <label style={{ display: "flex", gap: 8, alignItems: "flex-start", textTransform: "none", fontFamily: "var(--sans)", fontSize: ".9rem", color: "var(--ink)" }}>
          <input type="checkbox" style={{ width: "auto" }} checked={own} onChange={(e) => setOwn(e.target.checked)} />
          <span>I confirm that I own this content or have the necessary permission to upload it.</span>
        </label>

        <button className="btn p" type="submit" disabled={busy} style={{ marginTop: 18 }}>
          {busy ? "Processing…" : "Begin the Chase"}
        </button>

        {msg && (
          <p className={msg.type === "err" ? "err" : "ok"} style={{ marginTop: 14, fontFamily: "var(--sans)" }}>
            {msg.text}
          </p>
        )}
      </form>

      <p className="muted" style={{ marginTop: 18, fontSize: ".82rem" }}>
        Approved and Reward unlock once a reviewer checks your upload — never before.
      </p>
    </main>
    </>
  );
}
