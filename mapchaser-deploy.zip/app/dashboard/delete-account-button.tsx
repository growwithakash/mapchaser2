"use client";
import { useState } from "react";

export default function DeleteAccountButton() {
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function handleDelete() {
    setBusy(true);
    setErr(null);
    try {
      const res = await fetch("/api/account/delete", { method: "POST" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not delete account.");
      window.location.href = "/";
    } catch (e: any) {
      setErr(e.message);
      setBusy(false);
    }
  }

  if (!confirming) {
    return (
      <button className="btn o" onClick={() => setConfirming(true)} style={{ borderColor: "var(--bad)", color: "var(--bad)" }}>
        Delete my account
      </button>
    );
  }

  return (
    <div>
      <p className="err">
        This permanently deletes your account, uploads, wallet and history. This cannot be undone.
      </p>
      <div className="row" style={{ marginTop: 10 }}>
        <button className="btn p" onClick={handleDelete} disabled={busy} style={{ background: "var(--bad)" }}>
          {busy ? "Deleting…" : "Yes, permanently delete"}
        </button>
        <button className="btn o" onClick={() => setConfirming(false)} disabled={busy}>
          Cancel
        </button>
      </div>
      {err && <p className="err" style={{ marginTop: 10 }}>{err}</p>}
    </div>
  );
}
