import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { signOut } from "./actions";
import DeleteAccountButton from "./delete-account-button";
import SiteNav from "@/components/site-nav";

export default async function Dashboard() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const [{ data: wallet }, { data: uploads }, { data: profile }, { data: withdrawals }] = await Promise.all([
    supabase.from("wallets").select("*").eq("user_id", user.id).single(),
    supabase.from("uploads").select("*").eq("user_id", user.id).order("created_at", { ascending: false }),
    supabase.from("profiles").select("strikes, suspended, full_name, date_of_birth").eq("id", user.id).single(),
    supabase.from("withdrawals").select("*").eq("user_id", user.id).order("requested_at", { ascending: false }).limit(5),
  ]);

  if (profile && !profile.date_of_birth) redirect("/complete-profile");

  return (
    <>
      <SiteNav />
      <main className="wrap">
        <div className="row" style={{ justifyContent: "space-between" }}>
          <div>
            <span style={{ fontFamily: "var(--mono)", fontSize: ".72rem", letterSpacing: ".1em", color: "var(--sand)", textTransform: "uppercase" }}>
              Expedition Log
            </span>
            <h1 style={{ marginTop: 6 }}>Welcome Back, Chaser</h1>
          </div>
          <form action={signOut}>
            <button className="btn o" type="submit">Sign out</button>
          </form>
        </div>
        <p className="muted">{profile?.full_name || user.email}</p>

        {profile?.suspended && (
          <div className="card" style={{ borderColor: "var(--bad)" }}>
            <p className="err" style={{ margin: 0 }}>
              Your account is suspended{profile.strikes > 0 ? ` (${profile.strikes} policy strike${profile.strikes > 1 ? "s" : ""})` : ""}. Uploading
              and redemption are disabled. If you believe this is a mistake, contact support.
            </p>
          </div>
        )}
        {!profile?.suspended && (profile?.strikes ?? 0) > 0 && (
          <p className="muted" style={{ fontSize: ".85rem" }}>
            {profile?.strikes} policy strike{profile!.strikes > 1 ? "s" : ""} on record. Repeated violations lead to suspension.
          </p>
        )}

        <div className="stats">
          <div className="stat"><span>Available Points</span><b>{wallet?.available_points ?? 0}</b></div>
          <div className="stat"><span>Pending Points</span><b>{wallet?.pending_points ?? 0}</b></div>
          <div className="stat"><span>Locked (Withdrawing)</span><b>{wallet?.locked_points ?? 0}</b></div>
          <div className="stat"><span>Lifetime Earned</span><b>{wallet?.lifetime_earned ?? 0}</b></div>
          <div className="stat"><span>Redeemed</span><b>{wallet?.redeemed_points ?? 0}</b></div>
        </div>

        <div className="card">
          <div className="row" style={{ justifyContent: "space-between" }}>
            <h2>My Journeys</h2>
            <a className="btn p" href="/upload">Start a Chase</a>
          </div>
          {!uploads?.length && <p className="muted">No uploads yet — capture your first journey.</p>}
          {!!uploads?.length && (
            <table>
              <thead>
                <tr><th>Title</th><th>Category</th><th>Status</th><th>Points</th></tr>
              </thead>
              <tbody>
                {uploads.map((u) => (
                  <tr key={u.id}>
                    <td>{u.title}<br /><span className="muted">{u.location}</span></td>
                    <td>{u.category}</td>
                    <td><span className={`pill ${u.status}`}>{u.status.replace("_", " ")}</span></td>
                    <td>{u.points_awarded}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="card">
          <div className="row" style={{ justifyContent: "space-between" }}>
            <h2>Redemption</h2>
            <a className="btn p" href="/withdraw">Redeem Points</a>
          </div>
          {!withdrawals?.length && <p className="muted">No redemption requests yet.</p>}
          {!!withdrawals?.length && (
            <table>
              <thead>
                <tr><th>Points</th><th>Method</th><th>Final Amount</th><th>Status</th></tr>
              </thead>
              <tbody>
                {withdrawals.map((w) => (
                  <tr key={w.id}>
                    <td>{w.points}</td>
                    <td>{w.payment_method.replace("_", " ")}</td>
                    <td>₹{Number(w.final_amount).toFixed(2)}</td>
                    <td><span className={`pill ${w.status === "completed" ? "approved" : w.status === "rejected" || w.status === "cancelled" ? "rejected" : "pending"}`}>{w.status}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="card">
          <h2>Account &amp; Data</h2>
          <p className="muted">
            Manage your data under our <a href="/copyright" style={{ textDecoration: "underline" }}>Copyright</a> process,
            or permanently delete your account below.
          </p>
          <div style={{ marginTop: 14 }}>
            <DeleteAccountButton />
          </div>
        </div>
      </main>
    </>
  );
}
