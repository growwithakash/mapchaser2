import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";

/**
 * Deletes the signed-in user's account and all owned data (uploads, wallet,
 * transactions, reports — all cascade via foreign keys).
 *
 * Requires SUPABASE_SERVICE_ROLE_KEY to be set as a server-only environment
 * variable. If it is not available, this fails safely (no partial deletion,
 * clear error) rather than silently doing nothing or deleting the wrong data.
 */
export async function POST(request: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Not signed in." }, { status: 401 });
  }

  let admin;
  try {
    admin = createAdminClient();
  } catch (err: any) {
    return NextResponse.json(
      { error: "Account deletion is not configured on this server yet. " + err.message },
      { status: 503 }
    );
  }

  const { error } = await admin.auth.admin.deleteUser(user.id);
  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  await supabase.auth.signOut();
  return NextResponse.json({ ok: true });
}
