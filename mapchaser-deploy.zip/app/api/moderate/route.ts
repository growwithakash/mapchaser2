import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { createClient } from "@/lib/supabase/server";
import { computePhash, hammingDistanceHex } from "@/lib/moderation/phash";
import { moderateImageWithClaude, type ModerationVerdict } from "@/lib/moderation/claude";
import { extractVideoKeyframes } from "@/lib/moderation/video";
import { notify } from "@/lib/notifications/send";

export const maxDuration = 60; // seconds — video extraction + multiple vision calls need headroom.
// Current Vercel Hobby and Pro plans both allow up to 300s, so 60s fits either —
// confirmed against Vercel's docs as of this build. If a future plan change lowers
// this, a timeout here still fails safely to manual_review, it just won't
// auto-decide that specific upload.

const DUPLICATE_THRESHOLD = 6; // Hamming distance out of 64 bits — tight, to avoid false accusations

export async function POST(request: Request) {
  const { upload_id } = await request.json();
  if (!upload_id) return NextResponse.json({ error: "upload_id required" }, { status: 400 });

  // Authenticate first: this endpoint spends AI credits.
  const userClient = await createClient();
  const { data: { user: caller } } = await userClient.auth.getUser();
  if (!caller) return NextResponse.json({ error: "Not signed in" }, { status: 401 });

  let admin: ReturnType<typeof createAdminClient>;
  try {
    admin = createAdminClient();
  } catch {
    return NextResponse.json({ status: "manual_review", reason: "moderation_not_configured" });
  }

  const { data: upload, error: fetchErr } = await admin.from("uploads").select("*").eq("id", upload_id).single();
  if (fetchErr || !upload) return NextResponse.json({ error: "Upload not found" }, { status: 404 });

  // Only the uploader or an admin may trigger moderation.
  if (upload.user_id !== caller.id) {
    const { data: callerIsAdmin } = await userClient.rpc("is_admin");
    if (!callerIsAdmin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  if (upload.status !== "pending") {
    return NextResponse.json({ status: upload.status, reason: "already_decided" });
  }

  async function failSafe(reason: string, errMsg?: string) {
    await admin.from("moderation_results").insert({
      upload_id, recommendation: "manual_review", reasoning: reason, model: "none", error: errMsg ?? reason,
    });
    await admin.from("uploads").update({ status: "manual_review" }).eq("id", upload_id);
    await notify({ type: "upload_manual_review", userId: upload.user_id, data: { title: upload.title } });
    return NextResponse.json({ status: "manual_review", reason });
  }

  const { data: fileBlob, error: dlErr } = await admin.storage.from("uploads").download(upload.file_path);
  if (dlErr || !fileBlob) return failSafe("storage_download_failed", dlErr?.message);
  const sourceBuffer = Buffer.from(await fileBlob.arrayBuffer());

  // ---- Gather frames: one for a photo, several sampled for a video ----
  let frames: Buffer[];
  if (upload.media_type === "photo") {
    frames = [sourceBuffer];
  } else {
    try {
      frames = await extractVideoKeyframes(sourceBuffer);
      if (!frames.length) throw new Error("No frames extracted.");
    } catch (e: any) {
      // ffmpeg-in-serverless is known-finicky — any failure here means we simply
      // can't see inside this video on this deployment. Never guess; review it.
      return failSafe("video_keyframe_extraction_failed", e.message);
    }
  }

  // ---- 1. Duplicate check per frame (perceptual hash against this platform's own content) ----
  let duplicateMatchId: string | null = null;
  let duplicateDistance: number | null = null;
  let hashFailed = false;
  try {
    const { data: existing } = await admin.from("content_fingerprints").select("upload_id, phash").neq("upload_id", upload_id);
    for (const frame of frames) {
      const phash = await computePhash(frame);
      await admin.from("content_fingerprints").insert({ upload_id, phash });
      for (const row of existing ?? []) {
        const dist = hammingDistanceHex(phash, row.phash);
        if (dist <= DUPLICATE_THRESHOLD && (duplicateDistance === null || dist < duplicateDistance)) {
          duplicateMatchId = row.upload_id;
          duplicateDistance = dist;
        }
      }
    }
  } catch {
    duplicateMatchId = null;
    hashFailed = true; // duplicate check did not run, so this can never be auto-approved
  }

  // ---- 2. Relevance / quality / safety via Claude vision, per frame ----
  let verdicts: ModerationVerdict[];
  try {
    verdicts = await Promise.all(
      frames.map((frame) => {
        const isPng = frame[0] === 0x89 && frame[1] === 0x50;
        return moderateImageWithClaude({
          base64: frame.toString("base64"),
          mediaType: isPng ? "image/png" : "image/jpeg",
          title: upload.title,
          location: upload.location,
          category: upload.category,
        });
      })
    );
  } catch (e: any) {
    return failSafe("ai_moderation_unavailable", e.message);
  }

  // ---- 3. Aggregate per-frame verdicts conservatively ----
  const relevance_score = Math.min(...verdicts.map((v) => v.relevance_score));
  const quality_pass = verdicts.every((v) => v.quality_pass);
  const safety_flags = Array.from(new Set(verdicts.flatMap((v) => v.safety_flags)));
  const anyReject = verdicts.some((v) => v.recommendation === "reject");
  const allApprove = verdicts.every((v) => v.recommendation === "approve");
  const reasoning = frames.length > 1
    ? verdicts.map((v, i) => `Frame ${i + 1}: ${v.reasoning}`).join(" ")
    : verdicts[0].reasoning;

  let finalStatus: "approved" | "manual_review" | "rejected" = "manual_review";
  let rejectionReason: string | null = null;

  if (duplicateMatchId && duplicateDistance !== null && duplicateDistance <= 3) {
    finalStatus = "manual_review"; // never auto-reject on hash alone
  } else if (anyReject) {
    finalStatus = "rejected";
    rejectionReason = safety_flags.length ? "unsafe_content" : "not_travel_nature";
  } else if (allApprove && !duplicateMatchId && !hashFailed) {
    finalStatus = "approved";
  } else {
    finalStatus = "manual_review";
  }

  await admin.from("moderation_results").insert({
    upload_id,
    relevance_score,
    quality_pass,
    quality_notes: verdicts.map((v) => v.quality_notes).join(" / "),
    safety_flags,
    duplicate_match_upload_id: duplicateMatchId,
    duplicate_distance: duplicateDistance,
    recommendation: anyReject ? "reject" : allApprove ? "approve" : "manual_review",
    reasoning,
    model: "claude-sonnet-4-6",
    frames_sampled: frames.length,
  });

  const updatePayload: any = { status: finalStatus };
  if (rejectionReason) updatePayload.rejection_reason = rejectionReason;
  const { data: updated } = await admin.from("uploads").update(updatePayload).eq("id", upload_id).select("points_awarded").single();

  if (finalStatus === "approved") {
    await notify({ type: "upload_approved", userId: upload.user_id, data: { title: upload.title, points: updated?.points_awarded ?? 0 } });
  } else if (finalStatus === "rejected") {
    await notify({ type: "upload_rejected", userId: upload.user_id, data: { title: upload.title, reason: rejectionReason ?? "other" } });
  } else {
    await notify({ type: "upload_manual_review", userId: upload.user_id, data: { title: upload.title } });
  }

  return NextResponse.json({ status: finalStatus });
}
