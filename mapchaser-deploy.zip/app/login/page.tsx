"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import SiteNav from "@/components/site-nav";

export default function LoginPage() {
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [dob, setDob] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ type: "err" | "ok"; text: string } | null>(null);

  const supabase = createClient();

  async function handleEmailSubmit(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    setBusy(true);
    try {
      if (mode === "up") {
        if (!dob) throw new Error("Please enter your date of birth.");
        const birth = new Date(dob);
        const now = new Date();
        let age = now.getFullYear() - birth.getFullYear();
        const beforeBirthday =
          now.getMonth() < birth.getMonth() ||
          (now.getMonth() === birth.getMonth() && now.getDate() < birth.getDate());
        if (beforeBirthday) age--;
        if (age < 18) throw new Error("You must be at least 18 years old to join Map Chaser.");

        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { data: { full_name: name, date_of_birth: dob } },
        });
        if (error) throw error;
        setMsg({ type: "ok", text: "Account created. Check your email to confirm, then sign in." });
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        window.location.href = "/dashboard";
      }
    } catch (err: any) {
      setMsg({ type: "err", text: err.message ?? "Something went wrong." });
    } finally {
      setBusy(false);
    }
  }

  async function handleGoogle() {
    setMsg(null);
    const redirectTo = `${window.location.origin}/auth/callback`;
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo },
    });
    if (error) setMsg({ type: "err", text: error.message });
  }

  return (
    <>
    <SiteNav />
    <main className="wrap">
      <h1>{mode === "in" ? "Welcome back" : "Create your account"}</h1>
      <p className="muted">Real Supabase authentication — sessions, hashed passwords, Google OAuth.</p>

      <div className="card">
        <div className="row" style={{ marginBottom: 14 }}>
          <button className="btn o" onClick={() => setMode("in")} style={{ fontWeight: mode === "in" ? 800 : 500 }}>
            Sign in
          </button>
          <button className="btn o" onClick={() => setMode("up")} style={{ fontWeight: mode === "up" ? 800 : 500 }}>
            Create account
          </button>
        </div>

        <form onSubmit={handleEmailSubmit}>
          {mode === "up" && (
            <>
              <label htmlFor="name">Full name</label>
              <input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
              <label htmlFor="dob">Date of birth</label>
              <input id="dob" type="date" value={dob} onChange={(e) => setDob(e.target.value)} required />
              <p className="muted" style={{ fontSize: ".78rem", marginTop: 6 }}>
                You must be at least 18 to join — rewards can be redeemed for real money.
              </p>
            </>
          )}
          <label htmlFor="email">Email</label>
          <input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          <label htmlFor="password">Password</label>
          <input
            id="password"
            type="password"
            minLength={6}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <button className="btn p" type="submit" disabled={busy} style={{ marginTop: 16, width: "100%" }}>
            {busy ? "Please wait…" : mode === "in" ? "Sign in" : "Create account"}
          </button>
        </form>

        <div className="row" style={{ margin: "16px 0" }}>
          <div style={{ flex: 1, height: 1, background: "var(--line)" }} />
          <span className="muted">or</span>
          <div style={{ flex: 1, height: 1, background: "var(--line)" }} />
        </div>

        <button className="btn o" onClick={handleGoogle} style={{ width: "100%" }}>
          Continue with Google
        </button>

        {msg && <p className={msg.type === "err" ? "err" : "ok"} style={{ marginTop: 14 }}>{msg.text}</p>}
      </div>
    </main>
    </>
  );
}
