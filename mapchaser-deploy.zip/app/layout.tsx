import type { Metadata, Viewport } from "next";
import "./globals.css";
import InstallApp from "@/components/install-app";

export const metadata: Metadata = {
  title: "Map Chaser",
  description: "Chase places. Capture moments. Earn rewards.",
  manifest: "/manifest.json",
  icons: {
    icon: [
      { url: "/icons/favicon-32.png", sizes: "32x32", type: "image/png" },
      { url: "/icons/favicon-16.png", sizes: "16x16", type: "image/png" },
      { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
    ],
    apple: "/icons/apple-touch-icon.png",
  },
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "Map Chaser",
  },
};

export const viewport: Viewport = {
  themeColor: "#12372A",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Space+Mono:wght@400;700&family=DM+Sans:wght@400;500;600&display=swap"
          rel="stylesheet"
        />
        <style>{`:root{--display:'Space Grotesk',system-ui,sans-serif;--mono:'Space Mono',monospace;--sans:'DM Sans',system-ui,sans-serif}`}</style>
      </head>
      <body>
        {children}
        <InstallApp />
      </body>
    </html>
  );
}
