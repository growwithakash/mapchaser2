"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import SiteNav from "@/components/site-nav";

export default function CompleteProfile() {
  const supabase = createClient();
  const [dob, setDob] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ type: "err" | "ok"; text: string } | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    if (!dob) { setMsg({ type: "err", text: "Please enter your date of birth." }); return; }

    setBusy(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { window.location.href = "/login"; return; }

      const { error } = await supabase.from("profiles").update({ date_of_birth: dob }).eq("id", user.id);
      if (error) throw error;

      // The database decides: an underage date of birth suspends the account.
      const { data: profile } = await supabase.from("profiles").select("suspended").eq("id", user.id).single();
      if (profile?.suspended) {
        setMsg({
          type: "err",
          text: "You must be at least 18 to use Map Chaser. This account has been restricted — contact support if you entered your birth date by mistake.",
        });
        return;
      }
      window.location.href = "/dashboard";
    } catch (err: any) {
      setMsg({ type: "err", text: err.message ?? "Could not save. Try again." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <SiteNav />
      <main className="wrap">
        <span style={{ fontFamily: "var(--mono)", fontSize: ".72rem", letterSpacing: ".1em", color: "var(--sand)", textTransform: "uppercase" }}>
          One Last Step
        </span>
        <h1 style={{ marginTop: 10 }}>Confirm Your Age</h1>
        <p className="muted">
          Map Chaser rewards can be redeemed for real money, so we need to confirm you&apos;re at least 18 before you continue.
        </p>
        <form className="card" onSubmit={handleSubmit}>
          <label htmlFor="dob">Date of birth</label>
          <input id="dob" type="date" value={dob} onChange={(e) => setDob(e.target.value)} required />
          <button className="btn p" type="submit" disabled={busy} style={{ marginTop: 16 }}>
            {busy ? "Saving…" : "Continue"}
          </button>
          {msg && <p className={msg.type === "err" ? "err" : "ok"} style={{ marginTop: 14 }}>{msg.text}</p>}
        </form>
      </main>
    </>
  );
}
