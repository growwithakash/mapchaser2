"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function ReportButton({ uploadId }: { uploadId: string }) {
  const supabase = createClient();
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState("not_original");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<string | null>(null);

  async function submit() {
    setBusy(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { setDone("Sign in to report content."); return; }
      const { error } = await supabase.from("reports").insert({ upload_id: uploadId, reporter_id: user.id, reason });
      if (error) throw error;
      setDone("Reported. Our team will review it.");
    } catch (e: any) {
      setDone(e.message ?? "Could not submit report.");
    } finally {
      setBusy(false);
    }
  }

  if (done) return <p className="muted" style={{ fontSize: ".72rem", marginTop: 6 }}>{done}</p>;

  if (!open) {
    return (
      <button onClick={() => setOpen(true)} style={{ background: "none", border: "none", color: "var(--mute)", fontFamily: "var(--mono)", fontSize: ".66rem", textTransform: "uppercase", cursor: "pointer", padding: 0, marginTop: 6 }}>
        Report
      </button>
    );
  }

  return (
    <div style={{ marginTop: 6, display: "flex", gap: 6, alignItems: "center" }}>
      <select value={reason} onChange={(e) => setReason(e.target.value)} style={{ width: "auto", padding: "4px 6px", fontSize: ".72rem" }}>
        <option value="not_original">Not original</option>
        <option value="inappropriate">Inappropriate</option>
        <option value="spam">Spam</option>
        <option value="not_mine">Not theirs</option>
        <option value="other">Other</option>
      </select>
      <button className="btn o" onClick={submit} disabled={busy} style={{ padding: "4px 10px", fontSize: ".66rem" }}>
        {busy ? "…" : "Submit"}
      </button>
    </div>
  );
}
