import { createClient } from "@/lib/supabase/server";
import SiteNav from "@/components/site-nav";
import ReportButton from "./report-button";
import SponsoredStrip from "@/components/sponsored-strip";

const CATEGORIES = [
  "Mountains","Forest","Waterfall","Beach","Lake","Wildlife","Landscape",
  "Sunrise","Sunset","Adventure","Road Trip","Camping","City","Heritage","Travel","Nature",
];

export default async function ExplorePage({
  searchParams,
}: { searchParams: Promise<{ category?: string; q?: string }> }) {
  const { category, q } = await searchParams;
  const supabase = await createClient();

  let query = supabase
    .from("uploads")
    .select("id, title, location, category, media_type, file_path, created_at")
    .eq("status", "approved")
    .order("created_at", { ascending: false })
    .limit(60);

  if (category) query = query.eq("category", category);
  if (q) query = query.or(`title.ilike.%${q}%,location.ilike.%${q}%`);

  const { data: uploads } = await query;

  const withUrls = await Promise.all(
    (uploads ?? []).map(async (u) => {
      const { data } = await supabase.storage.from("uploads").createSignedUrl(u.file_path, 3600);
      return { ...u, url: data?.signedUrl ?? null };
    })
  );

  return (
    <>
      <SiteNav />
      <main className="wrap" style={{ maxWidth: 1000 }}>
        <span style={{ fontFamily: "var(--mono)", fontSize: ".72rem", letterSpacing: ".1em", color: "var(--sand)", textTransform: "uppercase" }}>
          The Gallery
        </span>
        <h1 style={{ marginTop: 10 }}>Explore Real Journeys</h1>
        <p className="muted">Approved uploads from real chasers. No likes, no followers — just the places.</p>

        <SponsoredStrip />

        <form style={{ display: "flex", gap: 8, flexWrap: "wrap", margin: "18px 0" }}>
          <input name="q" defaultValue={q} placeholder="Search title or location" style={{ maxWidth: 260 }} />
          <select name="category" defaultValue={category ?? ""}>
            <option value="">All categories</option>
            {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
          <button className="btn o" type="submit">Filter</button>
          {(category || q) && <a className="btn o" href="/explore">Clear</a>}
        </form>

        {!withUrls.length && (
          <div className="card">
            <p className="muted">
              Nothing approved yet{category || q ? " for this filter" : ""}. Be the first —{" "}
              <a href="/upload" style={{ textDecoration: "underline" }}>start a chase</a>.
            </p>
          </div>
        )}

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(220px,1fr))", gap: 14 }}>
          {withUrls.map((u) => (
            <div key={u.id} className="card" style={{ margin: 0, padding: 0, overflow: "hidden" }}>
              <div style={{ aspectRatio: "4/3", background: "var(--line)" }}>
                {u.url && u.media_type === "photo" && (
                  <img src={u.url} alt={u.title} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
                )}
                {u.url && u.media_type === "video" && (
                  <video src={u.url} controls style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                )}
              </div>
              <div style={{ padding: 14 }}>
                <span style={{ fontFamily: "var(--mono)", fontSize: ".66rem", color: "var(--sand)", textTransform: "uppercase" }}>{u.category}</span>
                <h3 style={{ fontSize: "1.05rem", marginTop: 4 }}>{u.title}</h3>
                <p className="muted" style={{ fontSize: ".82rem" }}>{u.location}</p>
                <ReportButton uploadId={u.id} />
              </div>
            </div>
          ))}
        </div>
      </main>
    </>
  );
}
