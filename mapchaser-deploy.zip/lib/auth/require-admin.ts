import "server-only";
import { notFound, redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export type AdminState = "anon" | "not_admin" | "needs_mfa_setup" | "needs_mfa_verify" | "ok";

/** Single source of truth for "is this request a signed-in, 2FA-verified admin?" */
export async function getAdminState() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { state: "anon" as AdminState, supabase, user: null };

  const { data: isAdmin } = await supabase.rpc("is_admin");
  if (!isAdmin) return { state: "not_admin" as AdminState, supabase, user };

  const { data: aal } = await supabase.auth.mfa.getAuthenticatorAssuranceLevel();
  if (aal?.currentLevel === "aal2") return { state: "ok" as AdminState, supabase, user };

  const { data: factors } = await supabase.auth.mfa.listFactors();
  const hasVerified = (factors?.totp ?? []).some((f) => f.status === "verified");
  return { state: (hasVerified ? "needs_mfa_verify" : "needs_mfa_setup") as AdminState, supabase, user };
}

/** For admin PAGES. Layout checks alone are not enough, so every page calls this too. */
export async function requireAdmin() {
  const s = await getAdminState();
  if (s.state === "anon") redirect("/login?next=/admin");
  if (s.state === "not_admin") notFound();
  if (s.state === "needs_mfa_setup") redirect("/admin/mfa-setup");
  if (s.state === "needs_mfa_verify") redirect("/admin/mfa-verify");
  return s;
}

/** For admin SERVER ACTIONS: throws instead of redirecting. Must run before any side effect (emails included). */
export async function assertAdmin() {
  const s = await getAdminState();
  if (s.state !== "ok") throw new Error("Forbidden");
  return s;
}
