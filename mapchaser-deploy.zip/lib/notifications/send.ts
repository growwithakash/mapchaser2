import { Resend } from "resend";
import { createAdminClient } from "@/lib/supabase/admin";
import { templates } from "./templates";

const FROM = process.env.NOTIFICATIONS_FROM_EMAIL || "Map Chaser <onboarding@resend.dev>";

type NotifyArgs =
  | { type: "upload_approved"; userId: string; data: { title: string; points: number } }
  | { type: "upload_rejected"; userId: string; data: { title: string; reason: string } }
  | { type: "upload_manual_review"; userId: string; data: { title: string } }
  | { type: "withdrawal_processing"; userId: string; data: { points: number; amount: string } }
  | { type: "withdrawal_completed"; userId: string; data: { points: number; amount: string } }
  | { type: "withdrawal_rejected"; userId: string; data: { points: number } }
  | { type: "withdrawal_cancelled"; userId: string; data: { points: number } }
  | { type: "account_suspended"; userId: string; data?: {} }
  | { type: "copyright_received"; email: string; data: { uploadTitle: string } };

/**
 * Best-effort email notification. NEVER throws — a failed or unconfigured
 * email provider must not block the real action (approval, withdrawal
 * status change, suspension) that triggered it. Every attempt is logged to
 * `notifications` for audit, whether it succeeds, fails, or is skipped.
 */
export async function notify(args: NotifyArgs): Promise<void> {
  let admin;
  try {
    admin = createAdminClient();
  } catch {
    return; // no service role configured — can't look up email or log; skip silently
  }

  let email: string | null = null;
  let userId: string | null = null;

  if ("userId" in args) {
    userId = args.userId;
    try {
      const { data } = await admin.auth.admin.getUserById(args.userId);
      email = data.user?.email ?? null;
    } catch {
      email = null;
    }
  } else {
    email = args.email;
  }
  if (!email) return;

  let built: { subject: string; html: string };
  switch (args.type) {
    case "upload_approved": built = templates.upload_approved(args.data.title, args.data.points); break;
    case "upload_rejected": built = templates.upload_rejected(args.data.title, args.data.reason); break;
    case "upload_manual_review": built = templates.upload_manual_review(args.data.title); break;
    case "withdrawal_processing": built = templates.withdrawal_processing(args.data.points, args.data.amount); break;
    case "withdrawal_completed": built = templates.withdrawal_completed(args.data.points, args.data.amount); break;
    case "withdrawal_rejected": built = templates.withdrawal_rejected(args.data.points); break;
    case "withdrawal_cancelled": built = templates.withdrawal_cancelled(args.data.points); break;
    case "account_suspended": built = templates.account_suspended(); break;
    case "copyright_received": built = templates.copyright_received(args.data.uploadTitle); break;
  }

  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    await admin.from("notifications").insert({
      user_id: userId, email, type: args.type, subject: built.subject,
      status: "skipped_no_api_key",
    });
    return;
  }

  try {
    const resend = new Resend(apiKey);
    const { error } = await resend.emails.send({ from: FROM, to: email, subject: built.subject, html: built.html });
    await admin.from("notifications").insert({
      user_id: userId, email, type: args.type, subject: built.subject,
      status: error ? "failed" : "sent",
      error: error ? JSON.stringify(error) : null,
    });
  } catch (e: any) {
    await admin.from("notifications").insert({
      user_id: userId, email, type: args.type, subject: built.subject,
      status: "failed", error: e.message,
    });
  }
}
