const wrap = (title: string, body: string) => `
<div style="font-family:'DM Sans',system-ui,sans-serif;background:#F5F0E6;padding:32px 20px;color:#17201C">
  <div style="max-width:480px;margin:0 auto;background:#fff;border:1px solid #E2DACB;border-radius:4px;padding:28px">
    <p style="font-family:monospace;font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:#B08B63;margin:0 0 10px">MAP CHASER</p>
    <h1 style="font-size:20px;margin:0 0 14px">${title}</h1>
    ${body}
  </div>
</div>`;

export const templates = {
  upload_approved: (title: string, points: number) => ({
    subject: `Approved — "${title}" earned ${points} points`,
    html: wrap("Your chase was approved", `<p>"${title}" passed verification and <b>${points} points</b> were added to your wallet.</p><p style="color:#68705f;font-size:13px">No action needed — check your dashboard any time.</p>`),
  }),
  upload_rejected: (title: string, reason: string) => ({
    subject: `Not approved — "${title}"`,
    html: wrap("This upload wasn't approved", `<p>"${title}" didn't pass verification (${reason.replace(/_/g, " ")}). No points were added.</p><p style="color:#68705f;font-size:13px">You're welcome to capture and submit another journey.</p>`),
  }),
  upload_manual_review: (title: string) => ({
    subject: `Under review — "${title}"`,
    html: wrap("A person is reviewing your upload", `<p>"${title}" needs a human look before a decision is made. No points yet — we'll let you know the outcome.</p>`),
  }),
  withdrawal_processing: (points: number, amount: string) => ({
    subject: `Redemption processing — ₹${amount}`,
    html: wrap("Your redemption is processing", `<p>Your request to redeem ${points} points (₹${amount}) is now being processed by our payment partner.</p>`),
  }),
  withdrawal_completed: (points: number, amount: string) => ({
    subject: `Redemption completed — ₹${amount}`,
    html: wrap("Payout sent", `<p>${points} points were redeemed for ₹${amount}. This should reflect on your end shortly, depending on your payment method.</p>`),
  }),
  withdrawal_rejected: (points: number) => ({
    subject: `Redemption rejected`,
    html: wrap("Your redemption request was rejected", `<p>${points} points have been returned to your available balance. Contact support if you have questions.</p>`),
  }),
  withdrawal_cancelled: (points: number) => ({
    subject: `Redemption cancelled`,
    html: wrap("Your redemption request was cancelled", `<p>${points} points have been returned to your available balance.</p>`),
  }),
  account_suspended: () => ({
    subject: `Your account has been suspended`,
    html: wrap("Account suspended", `<p>Your account was suspended after repeated policy violations. Uploading is disabled. If you believe this is a mistake, reply to this email.</p>`),
  }),
  copyright_received: (uploadTitle: string) => ({
    subject: `Copyright claim received`,
    html: wrap("We received your claim", `<p>Thanks — we've logged your copyright claim${uploadTitle ? ` regarding "${uploadTitle}"` : ""}. Our team reviews every claim and will follow up by email.</p>`),
  }),
};
