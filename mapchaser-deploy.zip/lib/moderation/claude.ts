import Anthropic from "@anthropic-ai/sdk";

export type ModerationVerdict = {
  relevance_score: number; // 0-100: how clearly travel/nature related
  quality_pass: boolean;
  quality_notes: string;
  safety_flags: string[]; // e.g. ["explicit"], ["violence"], [] if clean
  recommendation: "approve" | "manual_review" | "reject";
  reasoning: string;
};

/**
 * Sends the image to Claude's vision API for a real relevance/quality/safety
 * assessment. This does NOT check originality against the wider internet —
 * only this function's three checks. If the API key is missing or the call
 * fails/returns something unparseable, this throws — the caller must treat
 * that as "verification unavailable" and fail safely to manual_review, never
 * auto-approve.
 */
export async function moderateImageWithClaude(params: {
  base64: string;
  mediaType: "image/jpeg" | "image/png" | "image/webp" | "image/gif";
  title: string;
  location: string;
  category: string;
}): Promise<ModerationVerdict> {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) throw new Error("ANTHROPIC_API_KEY is not configured.");

  const client = new Anthropic({ apiKey });

  const prompt = `You are a content moderator for Map Chaser, a travel/nature photo platform.
Evaluate this image honestly and conservatively. The uploader claims:
Title: "${params.title}"
Location: "${params.location}"
Category: "${params.category}"

Check three things only:
1. Relevance: is this genuinely a travel or nature photo (landscape, wildlife, places, journeys)? Score 0-100.
2. Quality: is it corrupt, blank, solid black, extremely blurry, or unusably low-resolution? (quality_pass: true means it's fine)
3. Safety: does it contain sexual content, graphic violence/gore, hate symbols, or other clearly unsafe material? List any that apply in safety_flags, else [].

Do NOT attempt to judge whether this photo was copied from elsewhere on the internet — you cannot verify that from a single image, so never factor it into your recommendation.

Recommend "reject" only if you are highly confident it is clearly not travel/nature content, or clearly unsafe. Recommend "manual_review" whenever you are at all uncertain. Recommend "approve" only when relevance is high, quality passes, and there are no safety flags.

Respond with ONLY this exact JSON shape, no other text:
{"relevance_score": <0-100>, "quality_pass": <true|false>, "quality_notes": "<short note>", "safety_flags": [<strings>], "recommendation": "<approve|manual_review|reject>", "reasoning": "<one or two sentences>"}`;

  const msg = await client.messages.create({
    model: "claude-sonnet-4-6",
    max_tokens: 500,
    messages: [
      {
        role: "user",
        content: [
          { type: "image", source: { type: "base64", media_type: params.mediaType, data: params.base64 } },
          { type: "text", text: prompt },
        ],
      },
    ],
  });

  const textBlock = msg.content.find((b: any) => b.type === "text") as any;
  if (!textBlock) throw new Error("No text response from moderation model.");

  const cleaned = textBlock.text.trim().replace(/^```json\s*|```$/g, "");
  let parsed: ModerationVerdict;
  try {
    parsed = JSON.parse(cleaned);
  } catch {
    throw new Error("Moderation model returned unparseable output.");
  }

  if (
    typeof parsed.relevance_score !== "number" ||
    typeof parsed.quality_pass !== "boolean" ||
    !Array.isArray(parsed.safety_flags) ||
    !["approve", "manual_review", "reject"].includes(parsed.recommendation)
  ) {
    throw new Error("Moderation model returned an unexpected shape.");
  }

  return parsed;
}
