import { execFile } from "child_process";
import { promisify } from "util";
import { writeFile, readFile, unlink, mkdtemp, rm } from "fs/promises";
import { tmpdir } from "os";
import path from "path";
import ffmpegPath from "ffmpeg-static";

const execFileAsync = promisify(execFile);

async function probeDuration(ffmpeg: string, inputPath: string): Promise<number> {
  try {
    await execFileAsync(ffmpeg, ["-i", inputPath]);
    return 0; // unreachable: ffmpeg with no output exits non-zero, caught below
  } catch (e: any) {
    const stderr: string = e?.stderr ?? "";
    const m = /Duration:\s*(\d+):(\d+):(\d+\.\d+)/.exec(stderr);
    if (!m) return 0;
    return Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]);
  }
}

/**
 * Extracts up to 3 JPEG keyframes (at ~15%, 50%, 85% of duration) from a video
 * buffer using a static ffmpeg binary, run as a subprocess. This is sampling,
 * not exhaustive coverage — three frames cannot see everything in a video.
 *
 * Runs in Vercel's writable /tmp only. ffmpeg-in-serverless is a known-finicky
 * pattern (binary execution, cold starts, function time limits); if ANYTHING
 * here fails, this throws and the caller must fail safely to manual_review —
 * never skip moderation silently.
 */
export async function extractVideoKeyframes(buffer: Buffer): Promise<Buffer[]> {
  if (!ffmpegPath) throw new Error("ffmpeg binary not available in this environment.");
  const ffmpeg = ffmpegPath as string;

  const dir = await mkdtemp(path.join(tmpdir(), "mapchaser-"));
  const inputPath = path.join(dir, "input.mp4");

  try {
    await writeFile(inputPath, buffer);

    const duration = await probeDuration(ffmpeg, inputPath);
    if (!duration || duration <= 0) throw new Error("Could not determine video duration.");

    const timestamps = [duration * 0.15, duration * 0.5, duration * 0.85];
    const frames: Buffer[] = [];

    for (let i = 0; i < timestamps.length; i++) {
      const outPath = path.join(dir, `frame-${i}.jpg`);
      await execFileAsync(ffmpeg, [
        "-ss", timestamps[i].toFixed(2),
        "-i", inputPath,
        "-frames:v", "1",
        "-q:v", "3",
        "-y", outPath,
      ]);
      frames.push(await readFile(outPath));
    }

    return frames;
  } finally {
    await rm(dir, { recursive: true, force: true }).catch(() => {});
  }
}
