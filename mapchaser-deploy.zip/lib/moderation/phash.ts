import Jimp from "jimp";

/**
 * Average-hash (aHash) perceptual hash: resize to 8x8 grayscale, compare each
 * pixel to the mean, producing a 64-bit fingerprint as a hex string. Near-duplicate
 * images (resized, recompressed, lightly cropped/filtered) land a small Hamming
 * distance apart. This runs entirely on our own server — no third-party API,
 * and it only catches duplicates already on this platform, not the wider internet.
 */
export async function computePhash(buffer: Buffer): Promise<string> {
  const img = await Jimp.read(buffer);
  img.resize(8, 8).grayscale();

  const pixels: number[] = [];
  img.scan(0, 0, 8, 8, function (x, y, idx) {
    pixels.push(this.bitmap.data[idx]);
  });

  const avg = pixels.reduce((a, b) => a + b, 0) / pixels.length;
  let bits = "";
  for (const p of pixels) bits += p >= avg ? "1" : "0";

  // pack 64 bits into a 16-char hex string
  let hex = "";
  for (let i = 0; i < 64; i += 4) {
    hex += parseInt(bits.slice(i, i + 4), 2).toString(16);
  }
  return hex;
}

export function hammingDistanceHex(a: string, b: string): number {
  if (a.length !== b.length) return 64;
  let dist = 0;
  for (let i = 0; i < a.length; i++) {
    const x = parseInt(a[i], 16) ^ parseInt(b[i], 16);
    dist += [0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4][x];
  }
  return dist;
}
