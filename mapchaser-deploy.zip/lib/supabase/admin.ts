import { createClient as createSupabaseClient } from "@supabase/supabase-js";

/**
 * SERVER-ONLY client using the service role key. This bypasses Row Level
 * Security entirely — never import this file in a Client Component, and
 * never send SUPABASE_SERVICE_ROLE_KEY to the browser. It must NOT be
 * prefixed with NEXT_PUBLIC_.
 */
export function createAdminClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL!;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!serviceKey) {
    throw new Error(
      "SUPABASE_SERVICE_ROLE_KEY is not set. Add it as a server-only env var (never NEXT_PUBLIC_) " +
      "from Supabase Dashboard > Project Settings > API."
    );
  }
  return createSupabaseClient(url, serviceKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
}
