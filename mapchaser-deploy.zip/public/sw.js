// Map Chaser service worker — deliberately minimal.
//
// This app deals in real auth sessions, real money (wallet/withdrawals), and
// real moderation state. Caching API responses or data pages could show a
// user a stale balance or a stale upload status, which is worse than no
// offline support at all. So this worker does exactly one thing: show a
// branded offline page for full-page navigations when there's no network.
// Every other request (API routes, Supabase calls, JS/CSS/images) passes
// straight through to the network, uncached, always fresh.

const OFFLINE_URL = "/offline";
const CACHE = "mapchaser-shell-v1";

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE).then((cache) => cache.addAll([OFFLINE_URL])).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener("fetch", (event) => {
  if (event.request.mode !== "navigate") return; // let everything else hit the network normally

  event.respondWith(
    fetch(event.request).catch(() =>
      caches.open(CACHE).then((cache) => cache.match(OFFLINE_URL))
    )
  );
});
