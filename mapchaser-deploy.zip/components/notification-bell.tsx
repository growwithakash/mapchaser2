"use client";
import { useEffect, useRef, useState } from "react";
import { createClient } from "@/lib/supabase/client";

type Notif = { id: string; subject: string; type: string; read_at: string | null; created_at: string };

function timeAgo(iso: string) {
  const s = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}

export default function NotificationBell() {
  const supabase = createClient();
  const [userId, setUserId] = useState<string | null>(null);
  const [items, setItems] = useState<Notif[]>([]);
  const [open, setOpen] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let channel: ReturnType<typeof supabase.channel> | null = null;

    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      setUserId(user.id);

      const { data } = await supabase
        .from("notifications")
        .select("id, subject, type, read_at, created_at")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(20);
      setItems(data ?? []);

      channel = supabase
        .channel("notifications-" + user.id)
        .on(
          "postgres_changes",
          { event: "INSERT", schema: "public", table: "notifications", filter: `user_id=eq.${user.id}` },
          (payload) => setItems((prev) => [payload.new as Notif, ...prev].slice(0, 20))
        )
        .subscribe();
    })();

    return () => { if (channel) supabase.removeChannel(channel); };
  }, []);

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (panelRef.current && !panelRef.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  if (!userId) return null;

  const unread = items.filter((n) => !n.read_at).length;

  async function markRead(id: string) {
    setItems((prev) => prev.map((n) => (n.id === id ? { ...n, read_at: new Date().toISOString() } : n)));
    await supabase.from("notifications").update({ read_at: new Date().toISOString() }).eq("id", id);
  }

  async function markAllRead() {
    const unreadIds = items.filter((n) => !n.read_at).map((n) => n.id);
    if (!unreadIds.length) return;
    setItems((prev) => prev.map((n) => (n.read_at ? n : { ...n, read_at: new Date().toISOString() })));
    await supabase.from("notifications").update({ read_at: new Date().toISOString() }).in("id", unreadIds);
  }

  return (
    <div style={{ position: "relative" }} ref={panelRef}>
      <button
        onClick={() => setOpen((o) => !o)}
        aria-label={`Notifications${unread ? `, ${unread} unread` : ""}`}
        style={{ position: "relative", background: "none", border: "none", cursor: "pointer", padding: 6, color: "var(--ink)" }}
      >
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M5 8a5 5 0 0 1 10 0c0 4 1.5 5.5 1.5 5.5h-13S5 12 5 8Z" />
          <path d="M8 16a2 2 0 0 0 4 0" />
        </svg>
        {unread > 0 && (
          <span style={{
            position: "absolute", top: 0, right: 0, background: "var(--gold)", color: "var(--ink)",
            borderRadius: 999, fontSize: ".62rem", fontWeight: 700, minWidth: 15, height: 15,
            display: "flex", alignItems: "center", justifyContent: "center", padding: "0 3px",
            fontFamily: "var(--mono)",
          }}>{unread > 9 ? "9+" : unread}</span>
        )}
      </button>

      {open && (
        <div style={{
          position: "absolute", right: 0, top: "calc(100% + 8px)", width: 320, maxHeight: 400, overflowY: "auto",
          background: "var(--card, #fff)", border: "1px solid var(--line)", borderRadius: 4,
          boxShadow: "0 16px 40px -16px rgba(23,32,28,.3)", zIndex: 50,
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 14px", borderBottom: "1px solid var(--line)" }}>
            <span style={{ fontFamily: "var(--mono)", fontSize: ".72rem", textTransform: "uppercase", letterSpacing: ".06em", color: "var(--sand)" }}>Notifications</span>
            {unread > 0 && (
              <button onClick={markAllRead} style={{ background: "none", border: "none", color: "var(--green)", fontSize: ".72rem", cursor: "pointer", textDecoration: "underline" }}>
                Mark all read
              </button>
            )}
          </div>

          {!items.length && (
            <p className="muted" style={{ padding: 18, fontSize: ".85rem", textAlign: "center" }}>Nothing yet — updates on your uploads and redemptions will show up here.</p>
          )}

          {items.map((n) => (
            <button
              key={n.id}
              onClick={() => markRead(n.id)}
              style={{
                display: "block", width: "100%", textAlign: "left", background: n.read_at ? "none" : "rgba(214,168,95,.08)",
                border: "none", borderBottom: "1px solid var(--line)", padding: "10px 14px", cursor: "pointer", color: "var(--ink)",
              }}
            >
              <div style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
                {!n.read_at && <span style={{ width: 6, height: 6, borderRadius: "50%", background: "var(--gold)", marginTop: 5, flex: "none" }} />}
                <div>
                  <p style={{ fontSize: ".84rem", margin: 0 }}>{n.subject}</p>
                  <span style={{ fontFamily: "var(--mono)", fontSize: ".66rem", color: "var(--mute, #68705f)" }}>{timeAgo(n.created_at)}</span>
                </div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
