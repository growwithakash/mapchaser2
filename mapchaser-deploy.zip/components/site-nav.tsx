import Link from "next/link";
import NotificationBell from "./notification-bell";

export default function SiteNav() {
  return (
    <header style={{ borderBottom: "1px solid var(--line)", padding: "16px 0" }}>
      <div className="wrap" style={{ padding: "0 20px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <Link className="brand" href="/">MAP CHASER</Link>
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <nav className="row" style={{ fontFamily: "var(--mono)", fontSize: ".72rem", letterSpacing: ".05em", textTransform: "uppercase" }}>
            <Link href="/explore" style={{ opacity: .75 }}>Explore</Link>
            <Link href="/dashboard" style={{ opacity: .75 }}>My Expedition</Link>
            <Link href="/upload" style={{ opacity: .75 }}>Start a Chase</Link>
            <Link href="/login" style={{ opacity: .75 }}>Sign in</Link>
          </nav>
          <NotificationBell />
        </div>
      </div>
    </header>
  );
}
