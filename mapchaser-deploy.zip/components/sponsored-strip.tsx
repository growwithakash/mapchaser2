import { createClient } from "@/lib/supabase/server";

const LABELS: Record<string, string> = {
  sponsored: "Sponsored",
  promoted: "Promoted",
  affiliate: "Affiliate",
};

/**
 * Real sponsored/promoted/affiliate placements, always clearly labelled and
 * visually separated from organic content — never styled to look like a
 * normal upload. rel="sponsored" is set for paid placements, per Google's
 * advertising guidelines. Shows nothing if there are no active promotions.
 */
export default async function SponsoredStrip() {
  const supabase = await createClient();
  const nowIso = new Date().toISOString();

  const { data: promotions } = await supabase
    .from("promotions")
    .select("id, type, title, link_url, destination")
    .eq("active", true)
    .or(`ends_at.is.null,ends_at.gt.${nowIso}`)
    .order("created_at", { ascending: false })
    .limit(4);

  if (!promotions?.length) return null;

  return (
    <div style={{ marginBottom: 28 }}>
      <span style={{ fontFamily: "var(--mono)", fontSize: ".66rem", letterSpacing: ".08em", textTransform: "uppercase", color: "var(--mute)" }}>
        Featured Partners
      </span>
      <div style={{ display: "flex", gap: 10, overflowX: "auto", marginTop: 10, paddingBottom: 4 }}>
        {promotions.map((p) => (
          <a
            key={p.id}
            href={p.link_url}
            target="_blank"
            rel={p.type === "promoted" ? "noopener noreferrer" : "sponsored noopener noreferrer"}
            style={{
              flex: "none", width: 240, border: "1.5px solid var(--gold)", borderRadius: 2, padding: 14,
              textDecoration: "none", color: "var(--ink)", background: "rgba(214,168,95,.06)",
            }}
          >
            <span style={{
              display: "inline-block", fontFamily: "var(--mono)", fontSize: ".64rem", textTransform: "uppercase",
              letterSpacing: ".05em", color: "var(--ink)", background: "var(--gold)", padding: "2px 8px", borderRadius: 2,
            }}>
              {LABELS[p.type] ?? p.type}
            </span>
            <p style={{ fontSize: ".9rem", fontWeight: 600, marginTop: 8 }}>{p.title}</p>
            {p.destination && <p className="muted" style={{ fontSize: ".78rem", marginTop: 2 }}>{p.destination}</p>}
          </a>
        ))}
      </div>
    </div>
  );
}
