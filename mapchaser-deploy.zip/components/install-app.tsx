"use client";
import { useEffect, useState } from "react";

const DISMISS_KEY = "mapchaser_install_dismissed";

export default function InstallApp() {
  const [promptEvent, setPromptEvent] = useState<any>(null);
  const [show, setShow] = useState(false);
  const [iosHint, setIosHint] = useState(false);

  useEffect(() => {
    // Register the service worker (safe, minimal — see public/sw.js).
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => {});
    }

    const alreadyInstalled =
      window.matchMedia("(display-mode: standalone)").matches || (navigator as any).standalone === true;
    const dismissed = localStorage.getItem(DISMISS_KEY) === "1";
    if (alreadyInstalled || dismissed) return;

    const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);
    if (isIOS) {
      setIosHint(true);
      setShow(true);
      return;
    }

    function onPrompt(e: any) {
      e.preventDefault();
      setPromptEvent(e);
      setShow(true);
    }
    window.addEventListener("beforeinstallprompt", onPrompt);
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);

  function dismiss() {
    localStorage.setItem(DISMISS_KEY, "1");
    setShow(false);
  }

  async function install() {
    if (!promptEvent) return;
    promptEvent.prompt();
    await promptEvent.userChoice;
    setShow(false);
  }

  if (!show) return null;

  return (
    <div
      style={{
        position: "fixed", left: 0, right: 0, bottom: 0, zIndex: 80,
        background: "var(--ink)", color: "var(--ivory)",
        padding: "12px 16px", display: "flex", alignItems: "center", gap: 12,
        fontFamily: "var(--sans)", fontSize: ".86rem",
      }}
    >
      <img src="/icons/icon-192.png" alt="" width={32} height={32} style={{ borderRadius: 6, flex: "none" }} />
      <div style={{ flex: 1 }}>
        {iosHint ? (
          <span>Add Map Chaser to your Home Screen — tap <b>Share</b>, then <b>Add to Home Screen</b>.</span>
        ) : (
          <span>Install Map Chaser for quick access, on desktop or mobile.</span>
        )}
      </div>
      {!iosHint && (
        <button className="btn p" onClick={install} style={{ padding: "7px 16px", fontSize: ".78rem", flex: "none" }}>
          Install
        </button>
      )}
      <button
        onClick={dismiss}
        aria-label="Dismiss"
        style={{ background: "none", border: "none", color: "var(--ivory)", opacity: 0.7, fontSize: "1.1rem", cursor: "pointer", flex: "none" }}
      >
        ×
      </button>
    </div>
  );
}
